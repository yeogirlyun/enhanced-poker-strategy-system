#!/usr/bin/env python3
"""
Test Enhanced RPGW - Next Button Focus
====================================

This test focuses on the Next button functionality to step through
GTO hand actions one at a time, ensuring proper state updates and
rendering before implementing auto-replay.
"""

import sys
import os
import tkinter as tk
from tkinter import ttk
import json

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def create_next_button_test():
    """Create test focused on Next button functionality."""
    
    # Import required modules
    try:
        from ui.services.service_container import ServiceContainer
        from ui.services.theme_manager import ThemeManager
        from utils.sound_manager import SoundManager
        from core.pure_poker_state_machine import PurePokerStateMachine, GameConfig
        from core.hand_model import Hand
        
        print("✅ All imports successful")
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return None

    class SimpleEnhancedRPGW(ttk.Frame):
        """
        Simplified Enhanced RPGW focused on Next button functionality.
        
        Step-by-step action processing with detailed logging.
        """
        
        def __init__(self, parent, services, **kwargs):
            super().__init__(parent, **kwargs)
            
            self.services = services
            self.current_hand = None
            self.hand_actions = []
            self.current_action_index = 0
            
            # Get sound manager
            self.sound_manager = services.get_app("sound")
            if self.sound_manager:
                print("🔊 Sound manager available")
            else:
                print("⚠️ No sound manager - creating silent fallback")
                self.sound_manager = SoundManager(test_mode=True)
            
            # State object (simplified)
            self.state = {
                'pot': {'amount': 0.0},
                'seats': [],
                'board': [],
                'current_action': {
                    'player': None,
                    'action': None,
                    'amount': 0.0,
                    'description': 'No action'
                },
                'status': 'Ready'
            }
            
            self._setup_ui()
            
        def _setup_ui(self):
            """Set up simple UI focused on Next button."""
            # Main display
            self.main_frame = ttk.Frame(self)
            self.main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
            
            # Title
            title_label = ttk.Label(
                self.main_frame,
                text="🎯 Enhanced RPGW - Next Button Test",
                font=("Arial", 16, "bold")
            )
            title_label.pack(pady=(0, 20))
            
            # State display
            self.state_text = tk.Text(
                self.main_frame,
                height=20,
                width=80,
                font=("Courier", 10)
            )
            self.state_text.pack(fill=tk.BOTH, expand=True, pady=(0, 20))
            
            # Controls
            controls_frame = ttk.Frame(self.main_frame)
            controls_frame.pack(fill=tk.X, pady=(0, 10))
            
            ttk.Button(
                controls_frame,
                text="📂 Load GTO Hand",
                command=self.load_gto_hand
            ).pack(side=tk.LEFT, padx=(0, 10))
            
            self.next_btn = ttk.Button(
                controls_frame,
                text="▶️ Next Action",
                command=self.next_action,
                state="disabled"
            )
            self.next_btn.pack(side=tk.LEFT, padx=(0, 10))
            
            ttk.Button(
                controls_frame,
                text="🔄 Reset",
                command=self.reset_hand
            ).pack(side=tk.LEFT, padx=(0, 10))
            
            # Status
            self.status_label = ttk.Label(controls_frame, text="Ready to load hand")
            self.status_label.pack(side=tk.RIGHT)
            
            self._update_display()
            
        def load_gto_hand(self):
            """Load GTO hand and prepare for step-by-step replay."""
            try:
                print("\n🔄 Loading GTO hand...")
                
                # Load GTO hands
                with open('gto_hands.json', 'r') as f:
                    gto_hands = json.load(f)
                
                if not gto_hands:
                    self.status_label.config(text="❌ No GTO hands found")
                    return
                
                # Use first hand
                hand_data = gto_hands[0]
                self.current_hand = self._create_hand_from_json(hand_data)
                
                print(f"✅ Hand loaded: {self.current_hand.metadata.get('hand_id', 'Unknown')}")
                
                # Extract actions
                self._extract_actions()
                
                # Initialize state
                self._initialize_state()
                
                # Enable Next button
                self.next_btn.config(state="normal")
                
                hand_id = self.current_hand.metadata.get('hand_id', 'Unknown')
                self.status_label.config(text=f"Hand loaded: {hand_id}")
                
                print(f"📊 {len(self.hand_actions)} actions ready for replay")
                
                # Update display
                self._update_display()
                
            except Exception as e:
                print(f"❌ Error loading hand: {e}")
                self.status_label.config(text=f"Error: {e}")
                
        def _create_hand_from_json(self, hand_data):
            """Create Hand object from JSON."""
            return Hand(
                metadata=hand_data.get('metadata', {}),
                seats=hand_data.get('seats', []), 
                streets=hand_data.get('streets', {}),
                actions=hand_data.get('actions', []),
                pots=hand_data.get('pots', []),
                showdown=hand_data.get('showdown', {})
            )
            
        def _extract_actions(self):
            """Extract actions for replay."""
            self.hand_actions = []
            
            print("📝 Extracting hand actions...")
            
            # Add initial deal
            self.hand_actions.append({
                'type': 'deal_cards',
                'description': '🃏 Deal hole cards to players',
                'sound': 'deal',
                'data': {}
            })
            
            # Process streets
            for street_name, street_data in self.current_hand.streets.items():
                print(f"  Processing street: {street_name}")
                
                # Deal community cards (except preflop)
                if street_name != 'preflop':
                    self.hand_actions.append({
                        'type': 'deal_community',
                        'street': street_name,
                        'description': f'🃏 Deal {street_name}',
                        'sound': 'deal',
                        'data': {'street': street_name}
                    })
                
                # Add player actions
                actions = street_data.get('actions', [])
                print(f"    Found {len(actions)} player actions")
                
                for action in actions:
                    action_data = {
                        'type': 'player_action',
                        'player': action.get('player', 'Unknown'),
                        'action': action.get('action', 'check'),
                        'amount': action.get('amount', 0.0),
                        'description': self._format_action_description(action),
                        'sound': action.get('action', 'check').lower(),
                        'data': action
                    }
                    self.hand_actions.append(action_data)
            
            # Reset action index
            self.current_action_index = 0
            
            print(f"✅ Extracted {len(self.hand_actions)} total actions")
            
        def _format_action_description(self, action):
            """Format action description with emojis."""
            player = action.get('player', 'Unknown')
            action_type = action.get('action', 'check').lower()
            amount = action.get('amount', 0.0)
            
            action_emojis = {
                'fold': '🚫',
                'check': '✋', 
                'call': '📞',
                'bet': '💰',
                'raise': '⬆️'
            }
            
            emoji = action_emojis.get(action_type, '🎯')
            
            if action_type == 'fold':
                return f"{emoji} {player} folds"
            elif action_type == 'check':
                return f"{emoji} {player} checks"
            elif action_type == 'call':
                return f"{emoji} {player} calls ${amount:,.0f}"
            elif action_type in ['bet', 'raise']:
                return f"{emoji} {player} {action_type}s ${amount:,.0f}"
            else:
                return f"{emoji} {player} {action_type}"
                
        def _initialize_state(self):
            """Initialize state from loaded hand."""
            if not self.current_hand:
                return
                
            # Update seats
            seats = []
            for i, seat in enumerate(self.current_hand.seats):
                seat_data = {
                    'name': seat.get('name', f'Player {i+1}'),
                    'stack': seat.get('starting_stack', 1000),
                    'bet': 0.0,
                    'cards': seat.get('cards', []),
                    'folded': False,
                    'position': i
                }
                seats.append(seat_data)
            
            # Update state
            self.state.update({
                'seats': seats,
                'pot': {'amount': 0.0},
                'board': [],
                'current_action': {
                    'player': None,
                    'action': None, 
                    'amount': 0.0,
                    'description': 'Ready to start'
                },
                'status': f"Hand loaded - {len(self.hand_actions)} actions"
            })
            
        def next_action(self):
            """Execute next action step-by-step."""
            if not self.hand_actions:
                print("⚠️ No actions to execute")
                return
                
            if self.current_action_index >= len(self.hand_actions):
                print("✅ All actions completed")
                self.status_label.config(text="Hand complete")
                self.next_btn.config(state="disabled")
                return
            
            # Get current action
            action = self.hand_actions[self.current_action_index]
            
            print(f"\n🎬 Executing action {self.current_action_index + 1}/{len(self.hand_actions)}")
            print(f"   Type: {action['type']}")
            print(f"   Description: {action['description']}")
            
            # Execute action
            self._execute_action(action)
            
            # Play sound
            self._play_sound(action)
            
            # Update action index
            self.current_action_index += 1
            
            # Update status
            if self.current_action_index >= len(self.hand_actions):
                self.status_label.config(text="Hand complete!")
                self.next_btn.config(state="disabled")
            else:
                next_action_desc = self.hand_actions[self.current_action_index]['description']
                self.status_label.config(text=f"Next: {next_action_desc}")
            
            # Update display
            self._update_display()
            
            print(f"   ✅ Action executed successfully")
            
        def _execute_action(self, action):
            """Execute action and update state."""
            action_type = action['type']
            
            if action_type == 'deal_cards':
                # Cards already in state from initialization
                self.state['current_action'] = {
                    'player': 'Dealer',
                    'action': 'Deal',
                    'amount': 0.0,
                    'description': action['description']
                }
                
            elif action_type == 'deal_community':
                street = action['data']['street']
                
                # Add community cards based on street
                if street == 'flop':
                    self.state['board'] = ['XX', 'YY', 'ZZ']
                elif street == 'turn':
                    if len(self.state['board']) == 3:
                        self.state['board'].append('TT')
                elif street == 'river':
                    if len(self.state['board']) == 4:
                        self.state['board'].append('RR')
                
                self.state['current_action'] = {
                    'player': 'Dealer',
                    'action': f'Deal {street}',
                    'amount': 0.0,
                    'description': action['description']
                }
                
            elif action_type == 'player_action':
                player_name = action['player']
                action_name = action['action']
                amount = action['amount']
                
                # Find and update player
                for seat in self.state['seats']:
                    if seat['name'] == player_name:
                        if action_name.lower() == 'fold':
                            seat['folded'] = True
                        elif action_name.lower() in ['bet', 'call', 'raise']:
                            seat['bet'] = amount
                            seat['stack'] -= amount
                            self.state['pot']['amount'] += amount
                        break
                
                # Update current action
                self.state['current_action'] = {
                    'player': player_name,
                    'action': action_name,
                    'amount': amount,
                    'description': action['description']
                }
            
            # Update overall status
            progress = f"{self.current_action_index + 1}/{len(self.hand_actions)}"
            self.state['status'] = f"Action {progress}: {action['description']}"
            
        def _play_sound(self, action):
            """Play sound for action."""
            if not self.sound_manager:
                return
                
            try:
                action_type = action['type']
                
                if action_type in ['deal_cards', 'deal_community']:
                    self.sound_manager.play_card_sound('deal')
                    print("   🔊 Played card dealing sound")
                elif action_type == 'player_action':
                    sound = action['sound']
                    amount = action.get('amount', 0.0)
                    self.sound_manager.play_action_sound(sound, amount)
                    print(f"   🔊 Played action sound: {sound}")
                    
            except Exception as e:
                print(f"   ⚠️ Sound error: {e}")
                
        def reset_hand(self):
            """Reset hand to beginning."""
            print("\n🔄 Resetting hand...")
            
            self.current_action_index = 0
            
            if self.hand_actions:
                self._initialize_state()
                self.next_btn.config(state="normal")
                self.status_label.config(text="Hand reset - ready to start")
            else:
                self.state = {
                    'pot': {'amount': 0.0},
                    'seats': [],
                    'board': [],
                    'current_action': {
                        'player': None,
                        'action': None,
                        'amount': 0.0,
                        'description': 'No hand loaded'
                    },
                    'status': 'Ready'
                }
                self.next_btn.config(state="disabled")
                self.status_label.config(text="No hand loaded")
            
            self._update_display()
            print("✅ Reset complete")
            
        def _update_display(self):
            """Update the text display with current state."""
            self.state_text.delete(1.0, tk.END)
            
            display_text = f"""🎯 Enhanced RPGW State Display
{"="*50}

📊 CURRENT STATE:
  Status: {self.state['status']}
  
💰 POT:
  Amount: ${self.state['pot']['amount']:,.2f}
  
🃏 COMMUNITY CARDS:
  Board: {' '.join(self.state['board']) if self.state['board'] else '(none)'}
  
👥 PLAYERS:"""
            
            for seat in self.state['seats']:
                status = " (FOLDED)" if seat['folded'] else ""
                display_text += f"""
  {seat['name']}{status}:
    Stack: ${seat['stack']:,.0f} | Bet: ${seat['bet']:,.0f}
    Cards: {' '.join(seat['cards']) if seat['cards'] else '(hidden)'}"""
            
            display_text += f"""
            
🎬 CURRENT ACTION:
  Player: {self.state['current_action']['player'] or '(none)'}
  Action: {self.state['current_action']['action'] or '(none)'}
  Amount: ${self.state['current_action']['amount']:,.0f}
  Description: {self.state['current_action']['description']}
  
📈 REPLAY PROGRESS:"""
            
            if self.hand_actions:
                display_text += f"""
  Current: {self.current_action_index}/{len(self.hand_actions)}
  Next Action: {self.hand_actions[self.current_action_index]['description'] if self.current_action_index < len(self.hand_actions) else '(complete)'}"""
            else:
                display_text += "\n  (no hand loaded)"
                
            self.state_text.insert(1.0, display_text)

    # Create main window
    root = tk.Tk()
    root.title("Enhanced RPGW - Next Button Test")
    root.geometry("900x700")
    
    # Initialize services
    services = ServiceContainer()
    
    # Theme manager
    theme_manager = ThemeManager()
    services.provide_app("theme", theme_manager)
    
    # Sound manager
    sound_manager = SoundManager(test_mode=False)
    services.provide_app("sound", sound_manager)
    
    print("✅ Services initialized")
    
    # Create widget
    widget = SimpleEnhancedRPGW(root, services)
    widget.pack(fill=tk.BOTH, expand=True)
    
    print("✅ Enhanced RPGW Next Button Test created")
    
    return root, widget

if __name__ == "__main__":
    print("🚀 Starting Enhanced RPGW Next Button Test")
    print("=" * 60)
    
    try:
        root, widget = create_next_button_test()
        
        print("\n🎮 Next Button Test Ready!")
        print("Features:")
        print("- Step-by-step action execution")
        print("- Detailed state display")
        print("- Sound effects for each action")
        print("- Visual progress tracking")
        print("- Reset functionality")
        print("\n📖 Instructions:")
        print("1. Click 'Load GTO Hand' to load a hand")
        print("2. Click 'Next Action' to step through one action at a time")
        print("3. Watch the state display update after each action")
        print("4. Click 'Reset' to start over")
        print("\n🚨 NOTE: Run this in external terminal, not in Cursor")
        print("\nReady for external testing!")
        
    except Exception as e:
        print(f"❌ Test setup failed: {e}")
        import traceback
        traceback.print_exc()
