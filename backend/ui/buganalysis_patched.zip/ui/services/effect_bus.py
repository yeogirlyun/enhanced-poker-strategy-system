#!/usr/bin/env python3
"""
EffectBus - Coordinates sounds & animations; integrates with GameDirector.
"""
from __future__ import annotations

import os
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field

# Import VoiceManager for human voice announcements
try:
    from ...utils.voice_manager import VoiceManager
except ImportError:
    try:
        from utils.voice_manager import VoiceManager
    except ImportError:
        VoiceManager = None


# Minimal effect representation
@dataclass
class Effect:
    type: str
    id: Optional[str] = None
    name: Optional[str] = None
    ms: int = 200
    args: Dict[str, Any] = field(default_factory=dict)


class EffectBus:
    def __init__(self, game_director=None, sound_manager=None, event_bus=None, renderer=None):
        self.director = game_director
        self.sound = sound_manager
        self.event_bus = event_bus
        self.renderer = renderer
        self.enabled = True
        self.effects: List[Effect] = []
        self.next_id = 0
        
        # Initialize VoiceManager for human voice announcements
        self.voice_manager = None
        if VoiceManager:
            try:
                self.voice_manager = VoiceManager()
                print("🔊 EffectBus: VoiceManager initialized for human voice announcements")
            except Exception as e:
                print(f"⚠️ EffectBus: VoiceManager not available: {e}")
        
        # Initialize pygame mixer for audio
        try:
            import pygame
            pygame.mixer.init(
                frequency=22050, size=-16, channels=2, buffer=512
            )
            self.pygame_available = True
            print("🔊 EffectBus: Pygame mixer initialized for audio")
        except Exception as e:
            self.pygame_available = False
            print(f"⚠️ EffectBus: Pygame mixer not available: {e}")
        
        # Sound file mapping - comprehensive coverage of all poker events
        self.sound_mapping = {
            # Player Actions (Primary)
            "BET": "player_bet.wav",
            "RAISE": "player_raise.wav", 
            "CALL": "player_call.wav",
            "CHECK": "player_check.wav",
            "FOLD": "player_fold.wav",
            "ALL_IN": "player_all_in.wav",
            
            # Card Dealing
            "DEAL_HOLE": "card_deal.wav",
            "DEAL_BOARD": "card_deal.wav",
            "DEAL_FLOP": "card_deal.wav",
            "DEAL_TURN": "card_deal.wav",
            "DEAL_RIVER": "card_deal.wav",
            
            # Game Events
            "SHOWDOWN": "winner_announce.wav",
            "END_HAND": "winner_announce.wav",
            "POST_BLIND": "chip_bet.wav",
            "POST_SMALL_BLIND": "chip_bet.wav",
            "POST_BIG_BLIND": "chip_bet.wav",
            
            # Chip & Pot Actions
            "CHIP_BET": "chip_bet.wav",
            "CHIP_COLLECT": "pot_split.wav",
            "POT_RAKE": "pot_rake.wav",
            "POT_SPLIT": "pot_split.wav",
            
            # UI & Notifications
            "TURN_NOTIFY": "turn_notify.wav",
            "BUTTON_MOVE": "button_move.wav",
            "ACTION_TIMEOUT": "turn_notify.wav",
            
            # Special Events
            "HAND_START": "card_deal.wav",
            "ROUND_START": "turn_notify.wav",
            "ROUND_END": "pot_split.wav"
        }
        
        # Load sound files
        self.sounds = {}
        self._load_sounds()

    def set_game_director(self, game_director):
        """Set the game director for coordinating effects timing."""
        self.director = game_director
        print(f"🔊 EffectBus: Connected to GameDirector")

    def set_event_bus(self, event_bus):
        """Set the event bus for publishing effect events."""
        self.event_bus = event_bus
        print(f"🔊 EffectBus: Connected to EventBus")

    def _load_sounds(self):
        """Load all available sound files."""
        if not self.pygame_available:
            return
            
        try:
            import pygame
            sounds_dir = os.path.join(
                os.path.dirname(__file__), '..', '..', 'sounds'
            )
            
            for action, filename in self.sound_mapping.items():
                sound_path = os.path.join(sounds_dir, filename)
                if (os.path.exists(sound_path) and 
                    os.path.getsize(sound_path) > 100):  # Ensure file is not empty
                    try:
                        sound = pygame.mixer.Sound(sound_path)
                        self.sounds[action] = sound
                        print(f"🔊 EffectBus: Loaded sound {action} -> {filename}")
                    except Exception as e:
                        print(f"⚠️ EffectBus: Failed to load {filename}: {e}")
                else:
                    print(f"⚠️ EffectBus: Sound file not found or empty: {sound_path}")
                    
            print(f"🔊 EffectBus: Loaded {len(self.sounds)} sound files")
        except Exception as e:
            print(f"⚠️ EffectBus: Error loading sounds: {e}")

    def add_effect(self, effect: Effect) -> str:
        """Add an effect to the queue."""
        if not self.enabled:
            return ""
            
        effect.id = f"{effect.type}_{self.next_id}"
        self.next_id += 1
        self.effects.append(effect)
        
        # Notify event bus
        if self.event_bus:
            self.event_bus.publish(f"effect_bus:{effect.type}", {
                "id": effect.id,
                "name": effect.name,
                "ms": effect.ms,
                "args": effect.args
            })
        
        return effect.id

    def add_sound_effect(self, sound_name: str, ms: int = 200) -> str:
        """Add a sound effect."""
        effect = Effect(
            type="sound",
            name=sound_name,
            ms=ms
        )
        return self.add_effect(effect)

    def add_animation_effect(self, animation_name: str, ms: int = 300) -> str:
        """Add an animation effect."""
        effect = Effect(
            type="animation", 
            name=animation_name,
            ms=ms
        )
        return self.add_effect(effect)

    def add_banner_effect(self, message: str, banner_type: str = "info", ms: int = 2000) -> str:
        """Add a banner notification effect."""
        effect = Effect(
            type="banner",
            name=message,
            ms=ms,
            args={"type": banner_type}
        )
        return self.add_effect(effect)

    def add_poker_action_effects(self, action_type: str, player_name: str = ""):
        """Add effects for poker actions."""
        # Map action types to sound names
        sound_name = None
        
        # Player Actions
        if action_type in ["BET", "RAISE"]:
            sound_name = "BET"
        elif action_type == "CALL":
            sound_name = "CALL"
        elif action_type == "CHECK":
            sound_name = "CHECK"
        elif action_type == "FOLD":
            sound_name = "FOLD"
        elif action_type == "ALL_IN":
            sound_name = "ALL_IN"
            
        # Card Dealing
        elif action_type in ["DEAL_HOLE", "DEAL_BOARD", "DEAL_FLOP", "DEAL_TURN", "DEAL_RIVER"]:
            sound_name = "DEAL_HOLE"
            
        # Game Events
        elif action_type in ["SHOWDOWN", "END_HAND"]:
            sound_name = "SHOWDOWN"
        elif action_type in ["POST_BLIND", "POST_SMALL_BLIND", "POST_BIG_BLIND"]:
            sound_name = "POST_BLIND"
            
        # Chip & Pot Actions
        elif action_type in ["CHIP_BET", "CHIP_COLLECT", "POT_RAKE", "POT_SPLIT"]:
            sound_name = action_type
            
        # UI & Notifications
        elif action_type in ["TURN_NOTIFY", "BUTTON_MOVE", "ACTION_TIMEOUT"]:
            sound_name = action_type
            
        # Special Events
        elif action_type in ["HAND_START", "ROUND_START", "ROUND_END"]:
            sound_name = action_type
        
        # Add sound effect
        if sound_name and sound_name in self.sounds:
            self.add_sound_effect(sound_name, 300)
            print(f"🔊 EffectBus: Added sound effect: {sound_name}")
        
        # Add human voice announcement
        if self.voice_manager:
            try:
                # Map action types to voice actions
                voice_action = None
                if action_type in ["BET", "RAISE"]:
                    voice_action = "bet" if action_type == "BET" else "raise"
                elif action_type == "CALL":
                    voice_action = "call"
                elif action_type == "CHECK":
                    voice_action = "check"
                elif action_type == "FOLD":
                    voice_action = "fold"
                elif action_type == "ALL_IN":
                    voice_action = "all_in"
                elif action_type in ["DEAL_HOLE", "DEAL_BOARD"]:
                    voice_action = "dealing"
                
                if voice_action:
                    self.voice_manager.play_voice(voice_action)
                    print(f"🗣️ EffectBus: Added voice announcement: {voice_action}")
            except Exception as e:
                print(f"⚠️ EffectBus: Voice announcement failed: {e}")
        
        # Add animation effect for betting actions
        if action_type in ["BET", "RAISE", "CALL", "POST_BLIND", "POST_SMALL_BLIND", "POST_BIG_BLIND"]:
            self.add_animation_effect("chips_to_pot", 500)
            print(f"🎬 EffectBus: Started animation: chips_to_pot")
        
        # Add banner effect for player actions
        if player_name and action_type in ["BET", "RAISE", "CALL", "CHECK", "FOLD", "ALL_IN"]:
            banner_type = "success" if action_type in ["CALL", "CHECK"] else "action"
            self.add_banner_effect(f"{player_name}: {action_type}", banner_type, 2000)

    def update(self):
        """Update effect processing."""
        if not self.enabled:
            return
            
        # Process effects
        for effect in self.effects[:]:
            if effect.type == "sound":
                self._play_sound(effect)
            elif effect.type == "animation":
                self._start_animation(effect)
            elif effect.type == "banner":
                self._show_banner(effect)
            
            # Remove processed effects
            self.effects.remove(effect)

    def _play_sound(self, effect: Effect):
        """Play a sound effect."""
        if not self.pygame_available or not self.sounds:
            return
            
        try:
            sound_name = effect.name
            if sound_name in self.sounds:
                # Gate effects while sound plays
                if self.director:
                    self.director.gate_begin()
                
                # Play the sound
                try:
                self.sounds[sound_name].play()
            except Exception:
                pass
                print(f"🔊 EffectBus: Playing sound: {sound_name}")
                
                # Schedule gate end after sound duration
                if self.director:
                    self.director.gate_begin()
                    def end_gate():
                        self.director.gate_end()
                        print(f"🎭 EffectBus: Completed sound effect: {effect.id}")
                    
                    # Schedule gate end after sound duration (approximate)
                    if hasattr(self, 'event_bus') and self.event_bus:
                        self.event_bus.publish("effect_bus:sound", {
                            "id": effect.id,
                            "name": sound_name,
                            "completed": True
                        })
                    
                    # Use after() for timing if available
                    try:
                        import tkinter as tk
                        root = tk.Tk()
                        root.after(effect.ms, end_gate)
                        root.destroy()
                    except:
                        # Fallback: just end gate immediately
                        end_gate()
            else:
                print(f"⚠️ EffectBus: Sound not found: {sound_name}")
        except Exception as e:
            print(f"⚠️ EffectBus: Error playing sound: {e}")
            if self.director:
                self.director.gate_end()

    def _start_animation(self, effect: Effect):
        """Start an animation effect."""
        try:
            # Gate effects while animation runs
            if self.director:
                self.director.gate_begin()
            
            print(f"🎬 EffectBus: Started animation: {effect.name}")
            
            # Publish animation event
            if self.event_bus:
                self.event_bus.publish("effect_bus:animate", {
                    "id": effect.id,
                    "name": effect.name,
                    "ms": effect.ms,
                    "args": effect.args
                })
            
            # Schedule gate end after animation duration
            if self.director:
                def end_gate():
                    self.director.gate_end()
                    print(f"🎭 EffectBus: Completed animation effect: {effect.id}")
                
                try:
                    import tkinter as tk
                    root = tk.Tk()
                    root.after(effect.ms, end_gate)
                    root.destroy()
                except:
                    # Fallback: just end gate immediately
                    end_gate()
        except Exception as e:
            print(f"⚠️ EffectBus: Error starting animation: {e}")
            if self.director:
                self.director.gate_end()

    def _show_banner(self, effect: Effect):
        """Show a banner notification."""
        try:
            # Publish banner event
            if self.event_bus:
                self.event_bus.publish("effect_bus:banner_show", {
                    "id": effect.id,
                    "message": effect.name,
                    "type": effect.args.get("type", "info"),
                    "ms": effect.ms
                })
                print(f"🎭 EffectBus: Added banner effect: {effect.name}")
        except Exception as e:
            print(f"⚠️ EffectBus: Error showing banner: {e}")

    def clear_queue(self):
        """Clear all pending effects."""
        self.effects.clear()

    def stop_all_effects(self):
        """Stop all running effects."""
        if self.pygame_available:
            try:
                import pygame
                pygame.mixer.stop()
            except:
                pass
        self.clear_queue()

    def get_status(self) -> Dict[str, Any]:
        """Get current status."""
        return {
            "enabled": self.enabled,
            "effects_count": len(self.effects),
            "sounds_loaded": len(self.sounds),
            "pygame_available": self.pygame_available
        }

    def set_effect_enabled(self, enabled: bool):
        """Enable/disable effects."""
        self.enabled = enabled


class NoopEffectBus:
    """No-op EffectBus for testing."""
    def __init__(self, *args, **kwargs):
        pass
    
    def __getattr__(self, name):
        return lambda *args, **kwargs: None
