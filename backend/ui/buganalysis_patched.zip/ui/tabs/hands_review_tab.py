import tkinter as tk
from tkinter import ttk
import uuid
from typing import Optional
import math

# New UI Architecture imports
from ..state.actions import (
    SET_REVIEW_HANDS,
    SET_REVIEW_FILTER,
    SET_STUDY_MODE
)
from ..state.store import Store
from ..services.event_bus import EventBus
from ..services.service_container import ServiceContainer
from ..services.game_director import GameDirector
from ..services.effect_bus import EffectBus
from ..services.hands_repository import HandsRepository, HandsFilter, StudyMode

# PPSM architecture - no FPSM dependencies
from ..tableview.canvas_manager import CanvasManager
from ..tableview.layer_manager import LayerManager
from ..tableview.renderer_pipeline import RendererPipeline
from ..tableview.components.pot_display import PotDisplay
from ..tableview.components.seats import Seats
from ..tableview.components.community import Community
from ..tableview.components.table_felt import TableFelt
from ..tableview.components.dealer_button import DealerButton
from ..tableview.components.bet_display import BetDisplay
from ..tableview.components.action_indicator import ActionIndicator

# Import enhanced button components
try:
    from ..components.enhanced_button import PrimaryButton, SecondaryButton
except ImportError:
    # Fallback to basic buttons if enhanced buttons not available
    PrimaryButton = SecondaryButton = tk.Button

# Import ActionBanner for visual feedback
try:
    from ..components.action_banner import ActionBanner
except ImportError:
    print("⚠️ ActionBanner not available, using fallback")
    ActionBanner = None

# Core imports - fail fast if not available
USE_DEV_STUBS = False  # set True only in a test harness

try:
    from core.hand_model import Hand
    from core.hand_model_decision_engine import HandModelDecisionEngine
    # PPSM imports instead of FPSM
    from core.pure_poker_state_machine import PurePokerStateMachine, GameConfig
    # HandsReviewBotSession removed - using PPSMHandsReviewBotSession below
    from core.session_logger import get_session_logger
    # Sound manager for Enhanced RPGW
    from utils.sound_manager import SoundManager
except ImportError as e:
    if not USE_DEV_STUBS:
        raise ImportError(f"Critical core modules not available: {e}. This will break hands review functionality.") from e
    print("⚠️ Using dev stubs due to import error:", e)
    
    # Minimal stubs for development only
    class Hand:
        def __init__(self, data):
            if isinstance(data, dict):
                self.hand_id = data.get("hand_id", "Unknown")
                self.players = data.get("players", [])
                self.pot_size = data.get("pot_size", 0)
                self.small_blind = data.get("small_blind", 5)
                self.big_blind = data.get("big_blind", 10)
                self.community_cards = data.get("community_cards", [])
                self.dealer = data.get("dealer", 0)
                self.__dict__.update(data)

        @classmethod
        def from_dict(cls, data):
            return cls(data)

    class HandModelDecisionEngine:
        def __init__(self, hand):
            pass

        def is_session_complete(self):
            return False

    class GameConfig:
        def __init__(self, **kwargs):
            pass

    def get_session_logger():
        class FallbackLogger:
            def log_system(self, *args, **kwargs):
                pass

        return FallbackLogger()


class PPSMHandsReviewBotSession:
    """PPSM-based hands review session (replaces FPSM version)."""
    
    def __init__(self, config, session_logger=None, decision_engine=None):
        self.config = config
        self.session_logger = session_logger
        self.decision_engine = decision_engine
        self.ppsm = None
        self.hand_model = None
        self.is_complete = False
        self.session_active = False
    
    def set_preloaded_hand_data(self, hand_data):
        """Set the hand data for replay."""
        self.hand_model = hand_data.get("hand_model")
    
    def start(self):
        """Start the PPSM session."""
        try:
            if not self.hand_model:
                return False
            
            # Create PPSM instance  
            self.ppsm = PurePokerStateMachine(self.config)
            
            # Start replay using hand model
            results = self.ppsm.replay_hand_model(self.hand_model)
            
            self.is_complete = results.get('success', False)
            self.session_active = True
            return self.is_complete
            
        except Exception as e:
            print(f"⚠️ PPSM session start error: {e}")
            return False
    
    def get_game_state(self):
        """Get current game state."""
        if self.ppsm:
            return self.ppsm.get_game_info()
        return {}
    
    def is_session_complete(self):
        """Check if session is complete."""
        return self.is_complete


class ConcreteHandModelDecisionEngine:
    """Concrete wrapper for HandModelDecisionEngine."""

    def __init__(self, hand):
        self.hand = hand
        try:
            if HandModelDecisionEngine and hand:
                self._engine = HandModelDecisionEngine.__new__(HandModelDecisionEngine)
                self._engine.hand = hand
                if hasattr(self._engine, "_organize_actions_by_street"):
                    self._engine.actions_by_street = (
                        self._engine._organize_actions_by_street()
                    )
                self._engine.current_action_index = 0
                if hasattr(self._engine, "_get_betting_actions"):
                    self._engine.actions_for_replay = (
                        self._engine._get_betting_actions()
                    )
                    self._engine.total_actions = len(self._engine.actions_for_replay)
                else:
                    self._engine.actions_for_replay = []
                    self._engine.total_actions = 0
            else:
                self._engine = None
        except Exception as e:
            print(f"❌ Error initializing decision engine: {e}")
            self._engine = None

    def get_decision(self, player_index: int, game_state):
        if self._engine and hasattr(self._engine, "get_decision"):
            return self._engine.get_decision(player_index, game_state)
        return {
            "action": "fold",
            "amount": 0,
            "explanation": "Default action",
            "confidence": 0.5,
        }

    def is_session_complete(self):
        if self._engine and hasattr(self._engine, "is_session_complete"):
            return self._engine.is_session_complete()
        return True

    def reset(self):
        if self._engine and hasattr(self._engine, "reset"):
            self._engine.reset()

    def get_session_info(self):
        if self._engine and hasattr(self._engine, "hand"):
            # Handle both fallback Hand class (hand.hand_id) and real Hand class (hand.metadata.hand_id)
            hand_id = "Unknown"
            if hasattr(self._engine.hand, "hand_id"):
                hand_id = self._engine.hand.hand_id
            elif hasattr(self._engine.hand, "metadata") and hasattr(
                self._engine.hand.metadata, "hand_id"
            ):
                hand_id = self._engine.hand.metadata.hand_id

            return {
                "hand_id": hand_id,
                "total_actions": getattr(self._engine, "total_actions", 0),
                "current_action": getattr(self._engine, "current_action_index", 0),
                "engine_type": "HandModelDecisionEngine",
            }
        return {
            "hand_id": "Unknown",
            "total_actions": 0,
            "current_action": 0,
            "engine_type": "Fallback",
        }


class HandsReviewTab(ttk.Frame):
    """Hands Review tab implementing the full PRD requirements."""

    def __init__(self, parent, services: ServiceContainer):
        super().__init__(parent)
        self.services = services
        self.session_id = f"hands_review_{uuid.uuid4().hex[:8]}"

        # Get app services
        self.event_bus: EventBus = services.get_app("event_bus")
        self.store: Store = services.get_app("store")
        self.theme = services.get_app("theme")
        self.hands_repository: HandsRepository = services.get_app("hands_repository")
        # Sound service is optional; guard against missing service key
        try:
            self.sound_manager = services.get_app("sound")
        except Exception:
            self.sound_manager = None

        # Create fallback sound manager if not provided by services
        if not self.sound_manager:
            try:
                self.sound_manager = SoundManager(test_mode=False)  # Use real sound mode
                print("🔊 Enhanced RPGW: Created fallback sound manager")
            except Exception as e:
                print(f"⚠️ Enhanced RPGW: Could not create sound manager: {e}")
                self.sound_manager = None
        else:
            # Ensure sound manager is properly configured
            try:
                if hasattr(self.sound_manager, 'set_animation_mode'):
                    self.sound_manager.set_animation_mode(True)
                print("🔊 Enhanced RPGW: Using service sound manager")
            except Exception as e:
                print(f"⚠️ Enhanced RPGW: Sound manager config error: {e}")

        # Session state - using PPSM architecture only
        self.current_session: Optional[PPSMHandsReviewBotSession] = None
        self.session_active = False
        
        # Initialize GameDirector and EffectBus for seamless action sequencing
        self.game_director = GameDirector(event_bus=self.event_bus)
        self.effect_bus = EffectBus(
            game_director=self.game_director,
            sound_manager=self.sound_manager,
            event_bus=self.event_bus
        )
        
        # Connect GameDirector and EffectBus
        self.game_director.set_event_bus(self.event_bus)
        self.effect_bus.set_game_director(self.game_director)
        self.effect_bus.set_event_bus(self.event_bus)

        # Setup UI
        self.on_mount()

        # Subscribe to events and store changes
        self._setup_event_subscriptions()
        self.store.subscribe(self._on_store_change)

        # Initialize GTO hands for PPSM testing
        self.loaded_gto_hands = []
        # GTO hands will be loaded in on_mount() to ensure proper UI initialization order

    def on_mount(self):
        """Set up the tab layout per PRD design."""
        # Two-column layout: Controls (20%) | Poker Table (80%)
        # Using 1:4 ratio for poker table emphasis
        self.grid_columnconfigure(0, weight=1)  # Library + Filters & Controls (20%)
        self.grid_columnconfigure(1, weight=4)  # Poker Table (80%)
        self.grid_rowconfigure(0, weight=1)

        # Create the two main sections
        self._create_combined_left_section()
        self._create_poker_table_section()
        
        # Load GTO hands for PPSM testing
        self._load_gto_hands()
        
        # Refresh hands list now that GTO hands are loaded
        self._refresh_hands_list()
        
        # Start main update loop for GameDirector and EffectBus
        self._start_update_loop()
        
        # Setup ActionBanner for visual feedback
        self._setup_action_banner()

    def _create_combined_left_section(self):
        """Create the combined left section with hands library and controls."""
        # Get theme colors
        theme = self.theme.get_theme()

        # Main left frame
        left_frame = ttk.Frame(self)
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(5, 2.5), pady=5)
        left_frame.grid_columnconfigure(0, weight=1)
        left_frame.grid_rowconfigure(0, weight=60)  # Hands library gets 60%
        left_frame.grid_rowconfigure(1, weight=40)  # Controls get 40%

        # Apply theme colors to main left frame
        try:
            left_frame.configure(background=theme.get("panel.bg", "#111827"))
        except Exception:
            pass

        # Create library section at top
        self._create_library_section_in_frame(left_frame)

        # Create filters/controls section at bottom
        self._create_filters_section_in_frame(left_frame)

    def _create_library_section_in_frame(self, parent):
        """Create the Library section within the given parent frame."""
        # Get theme colors
        theme = self.theme.get_theme()

        library_frame = ttk.LabelFrame(parent, text="📚 Hands Library", padding=10)
        library_frame.grid(row=0, column=0, sticky="nsew", pady=(0, 2.5))

        # Apply theme colors to the frame
        try:
            library_frame.configure(
                background=theme.get("panel.bg", "#111827"),
                foreground=theme.get("panel.sectionTitle", "#C7D2FE"),
            )
        except Exception:
            pass  # Fallback to default colors if theming fails
        library_frame.grid_columnconfigure(0, weight=1)
        library_frame.grid_rowconfigure(
            3, weight=1
        )  # Hands list gets most space (shifted down due to theme selector)

        # Theme selector (at top) - 5 Professional Casino Schemes
        theme_frame = ttk.LabelFrame(
            library_frame, text="🎨 Professional Casino Themes", padding=5
        )
        theme_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        theme_frame.grid_columnconfigure(0, weight=1)

        theme_controls = ttk.Frame(theme_frame)
        theme_controls.grid(row=0, column=0, sticky="ew")

        current_theme = self.theme.current_profile_name()
        self.theme_var = tk.StringVar(value=current_theme)

        # All available themes from ThemeManager
        all_theme_names = self.theme.names()
        print(
            f"🎨 HandsReviewTab: Found {len(all_theme_names)} themes: {all_theme_names}"
        )

        # Fallback if no themes found
        if not all_theme_names:
            print("⚠️ No themes found, forcing theme manager reload...")
            # Try to reload theme manager
            try:
                from ..services.theme_factory import build_all_themes

                themes = build_all_themes()
                print(f"🔄 Force-built {len(themes)} themes: {list(themes.keys())}")
                # Register them with the theme manager
                for name, tokens in themes.items():
                    self.theme.register(name, tokens)
                all_theme_names = self.theme.names()
                print(
                    f"🎨 After reload: {len(all_theme_names)} themes: {all_theme_names}"
                )
            except Exception as e:
                print(f"❌ Failed to reload themes: {e}")
                # Get actual theme names from config, with ultimate fallback
                default_theme_data = self.theme.get_available_themes()
                all_theme_names = (
                    list(default_theme_data.keys())
                    if default_theme_data
                    else ["Forest Green Professional 🌿"]
                )

        # Theme icons are now embedded in theme names from JSON config
        # No need for separate THEME_ICONS or THEME_INTROS - all data comes from poker_themes.json

        # Create clean 4x4 grid layout for 16 themes with 20px font
        # Configure grid weights for even distribution
        for col_idx in range(4):
            theme_controls.grid_columnconfigure(col_idx, weight=1)

        for i, theme_name in enumerate(all_theme_names):
            row = i // 4  # 4 themes per row
            col = i % 4

            # Theme names from JSON config already include icons and formatting
            display_name = theme_name

            # Simple radiobutton with 20px font and equal spacing
            radio_btn = ttk.Radiobutton(
                theme_controls,
                text=display_name,
                variable=self.theme_var,
                value=theme_name,
                command=self._on_theme_change,
            )
            radio_btn.grid(row=row, column=col, sticky="w", padx=5, pady=3)

            # Configure font size to 20px and store reference for styling
            try:
                fonts = self.theme.get_fonts()
                radio_font = fonts.get(
                    "button", fonts.get("body", ("Inter", 20, "normal"))
                )
                radio_btn.configure(font=radio_font)
            except:
                # Fallback if font configuration fails
                pass

            # Store radio button reference for theme styling
            if not hasattr(self, "theme_radio_buttons"):
                self.theme_radio_buttons = []
            self.theme_radio_buttons.append(radio_btn)

            # Theme intro will update only on selection, not hover
            # Removed confusing hover effects that changed intro on mouse over

        # Apply initial theme styling to radio buttons
        self.after_idle(self._style_theme_radio_buttons)

        # Artistic Theme Info Panel - shows evocative descriptions (positioned AFTER theme controls)
        info_frame = ttk.Frame(theme_frame)
        info_frame.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        info_frame.grid_columnconfigure(0, weight=1)

        # Luxury Museum Placard - Theme intro with elegant styling
        fonts = self.theme.get_fonts()
        # Use theme-aware font for luxury feel
        fonts = self.theme.get_fonts()
        intro_font = fonts.get("intro", fonts.get("body", ("Georgia", 16, "normal")))

        # Create luxury museum placard frame with theme-aware styling
        base_colors = self.theme.get_base_colors()
        placard_bg = base_colors.get("panel_bg", "#2A2A2A")
        placard_accent = base_colors.get("highlight", "#D4AF37")

        placard_frame = tk.Frame(
            info_frame,
            relief="raised",
            borderwidth=2,
            bg=placard_bg,
            highlightbackground=placard_accent,
            highlightcolor=placard_accent,
            highlightthickness=1,
        )
        # Use theme dimensions for consistent spacing
        dimensions = self.theme.get_dimensions()
        medium_pad = dimensions["padding"]["medium"]
        placard_frame.grid(
            row=0, column=0, sticky="ew", padx=medium_pad, pady=medium_pad
        )
        placard_frame.grid_columnconfigure(0, weight=1)

        # Store reference to placard frame for dynamic styling
        self.placard_frame = placard_frame

        # Get initial theme colors instead of hardcoding
        base_colors = self.theme.get_base_colors()
        initial_bg = base_colors.get("panel_bg", "#1A1A1A")
        initial_fg = base_colors.get("text", "#F5F5DC")

        intro_height = dimensions["text_height"][
            "medium"
        ]  # Use medium instead of small for theme intros
        self.theme_intro_label = tk.Text(
            placard_frame,
            height=intro_height,
            wrap=tk.WORD,
            relief="flat",
            borderwidth=0,
            font=intro_font,
            state="disabled",
            cursor="arrow",
            padx=dimensions["padding"]["xlarge"],
            pady=dimensions["padding"]["medium"],
            bg=initial_bg,
            fg=initial_fg,
        )  # Dynamic theme colors
        self.theme_intro_label.grid(row=0, column=0, sticky="ew")

        # Show current theme's introduction
        self._show_theme_intro(current_theme)

        # Library type selector
        type_frame = ttk.Frame(library_frame)
        type_frame.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        type_frame.grid_columnconfigure(0, weight=1)

        self.library_type = tk.StringVar(value="legendary")
        ttk.Radiobutton(
            type_frame,
            text="🏆 Legendary",
            variable=self.library_type,
            value="legendary",
            command=self._on_library_type_change,
        ).grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(
            type_frame,
            text="🤖 Bot Sessions",
            variable=self.library_type,
            value="bot",
            command=self._on_library_type_change,
        ).grid(row=0, column=1, sticky="w")
        ttk.Radiobutton(
            type_frame,
            text="📥 Imported",
            variable=self.library_type,
            value="imported",
            command=self._on_library_type_change,
        ).grid(row=0, column=2, sticky="w")

        # Collections dropdown
        collections_frame = ttk.Frame(library_frame)
        collections_frame.grid(row=3, column=0, sticky="ew", pady=(0, 10))
        collections_frame.grid_columnconfigure(1, weight=1)

        ttk.Label(collections_frame, text="Collection:").grid(
            row=0, column=0, sticky="w", padx=(0, 5)
        )
        self.collection_var = tk.StringVar(value="🤖 GTO Hands")
        self.collection_combo = ttk.Combobox(
            collections_frame, textvariable=self.collection_var, state="readonly"
        )
        self.collection_combo.grid(row=0, column=1, sticky="ew")
        self.collection_combo.bind("<<ComboboxSelected>>", self._on_collection_change)

        # Hands listbox
        hands_frame = ttk.Frame(library_frame)
        hands_frame.grid(row=4, column=0, sticky="nsew", pady=(0, 10))
        hands_frame.grid_columnconfigure(0, weight=1)
        hands_frame.grid_rowconfigure(0, weight=1)

        # Get fonts from theme
        fonts = self.theme.get_fonts()
        body_font = fonts.get("body", ("Consolas", 20))

        self.hands_listbox = tk.Listbox(
            hands_frame, font=body_font, selectmode=tk.SINGLE
        )
        self.hands_listbox.grid(row=0, column=0, sticky="nsew")
        self.hands_listbox.bind("<<ListboxSelect>>", self._on_hand_select)

        # Apply theme colors to listbox with dynamic selection highlight
        try:
            # Get theme-specific selection highlight
            current_theme_name = self.theme.current() or "Forest Green Professional 🌿"
            # Get selection highlight from config-driven system
            base_colors = self.theme.get_base_colors()
            selection_highlight = {
                "color": base_colors.get(
                    "highlight", base_colors.get("accent", "#D4AF37")
                )
            }

            self.hands_listbox.configure(
                bg=theme.get("panel.bg", "#111827"),
                fg=theme.get("panel.fg", "#E5E7EB"),
                selectbackground=selection_highlight[
                    "color"
                ],  # Dynamic theme-specific highlight
                selectforeground=base_colors.get(
                    "highlight_text", base_colors.get("text", "#FFFFFF")
                ),  # Theme-aware text when highlighted
                highlightbackground=theme.get("panel.border", "#1F2937"),
                highlightcolor=theme.get("a11y.focusRing", "#22D3EE"),
            )
        except Exception:
            pass

        scrollbar = ttk.Scrollbar(
            hands_frame, orient="vertical", command=self.hands_listbox.yview
        )
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.hands_listbox.configure(yscrollcommand=scrollbar.set)

        # Hand details text (smaller in the combined layout)
        details_frame = ttk.LabelFrame(library_frame, text="Hand Details", padding=5)
        details_frame.grid(row=5, column=0, sticky="ew")
        details_frame.grid_columnconfigure(0, weight=1)

        small_font = fonts.get("small", ("Consolas", 16))
        details_height = self.theme.get_dimensions()["text_height"]["medium"]
        self.details_text = tk.Text(
            details_frame, height=details_height, wrap=tk.WORD, font=small_font
        )
        self.details_text.grid(row=0, column=0, sticky="ew")

        # Apply theme colors to details text
        try:
            self.details_text.configure(
                bg=theme.get("panel.bg", "#111827"),
                fg=theme.get("panel.fg", "#E5E7EB"),
                insertbackground=theme.get("panel.fg", "#E5E7EB"),
                highlightbackground=theme.get("panel.border", "#1F2937"),
                highlightcolor=theme.get("a11y.focusRing", "#22D3EE"),
            )
        except Exception:
            pass

    def _create_filters_section_in_frame(self, parent):
        """Create the Filters & Controls section within the given parent frame."""
        # Get theme colors
        theme = self.theme.get_theme()

        filters_frame = ttk.LabelFrame(
            parent, text="🔍 Filters & Study Mode", padding=10
        )
        filters_frame.grid(row=1, column=0, sticky="nsew", pady=(2.5, 0))

        # Apply theme colors to the frame
        try:
            filters_frame.configure(
                background=theme.get("panel.bg", "#111827"),
                foreground=theme.get("panel.sectionTitle", "#C7D2FE"),
            )
        except Exception:
            pass
        filters_frame.grid_columnconfigure(0, weight=1)

        # Study Mode selector
        study_frame = ttk.LabelFrame(filters_frame, text="Study Mode", padding=5)
        study_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))

        self.study_mode = tk.StringVar(value=StudyMode.REPLAY.value)
        ttk.Radiobutton(
            study_frame,
            text="🔄 Replay",
            variable=self.study_mode,
            value=StudyMode.REPLAY.value,
            command=self._on_study_mode_change,
        ).grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(
            study_frame,
            text="📊 Solver Diff",
            variable=self.study_mode,
            value=StudyMode.SOLVER_DIFF.value,
            command=self._on_study_mode_change,
        ).grid(row=1, column=0, sticky="w")
        ttk.Radiobutton(
            study_frame,
            text="🧠 Recall Quiz",
            variable=self.study_mode,
            value=StudyMode.RECALL_QUIZ.value,
            command=self._on_study_mode_change,
        ).grid(row=2, column=0, sticky="w")
        ttk.Radiobutton(
            study_frame,
            text="❓ Explain Mistake",
            variable=self.study_mode,
            value=StudyMode.EXPLAIN_MISTAKE.value,
            command=self._on_study_mode_change,
        ).grid(row=3, column=0, sticky="w")

        # Filters section
        filter_frame = ttk.LabelFrame(filters_frame, text="Filters", padding=5)
        filter_frame.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        filter_frame.grid_columnconfigure(1, weight=1)

        # Position filter
        ttk.Label(filter_frame, text="Position:").grid(
            row=0, column=0, sticky="w", padx=(0, 5)
        )
        self.position_var = tk.StringVar(value="All")
        position_combo = ttk.Combobox(
            filter_frame,
            textvariable=self.position_var,
            values=["All", "UTG", "MP", "CO", "BTN", "SB", "BB"],
            state="readonly",
            width=8,
        )
        position_combo.grid(row=0, column=1, sticky="w", pady=2)

        # Stack depth filter
        ttk.Label(filter_frame, text="Stack Depth:").grid(
            row=1, column=0, sticky="w", padx=(0, 5)
        )
        stack_frame = ttk.Frame(filter_frame)
        stack_frame.grid(row=1, column=1, sticky="w", pady=2)
        self.min_stack = tk.StringVar(value="20")
        self.max_stack = tk.StringVar(value="200")
        ttk.Entry(stack_frame, textvariable=self.min_stack, width=5).grid(
            row=0, column=0
        )
        ttk.Label(stack_frame, text=" - ").grid(row=0, column=1)
        ttk.Entry(stack_frame, textvariable=self.max_stack, width=5).grid(
            row=0, column=2
        )
        ttk.Label(stack_frame, text=" BB").grid(row=0, column=3)

        # Pot type filter
        ttk.Label(filter_frame, text="Pot Type:").grid(
            row=2, column=0, sticky="w", padx=(0, 5)
        )
        self.pot_type_var = tk.StringVar(value="All")
        pot_combo = ttk.Combobox(
            filter_frame,
            textvariable=self.pot_type_var,
            values=["All", "SRP", "3BP", "4BP+"],
            state="readonly",
            width=8,
        )
        pot_combo.grid(row=2, column=1, sticky="w", pady=2)

        # Search text
        ttk.Label(filter_frame, text="Search:").grid(
            row=3, column=0, sticky="w", padx=(0, 5)
        )
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(filter_frame, textvariable=self.search_var)
        search_entry.grid(row=3, column=1, sticky="ew", pady=2)
        search_entry.bind("<KeyRelease>", lambda e: self._apply_filters())

        # Apply filters button
        ttk.Button(
            filter_frame, text="Apply Filters", command=self._apply_filters
        ).grid(row=4, column=0, columnspan=2, pady=5)

        # Action buttons
        actions_frame = ttk.LabelFrame(filters_frame, text="Actions", padding=5)
        actions_frame.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        actions_frame.grid_columnconfigure(0, weight=1)

        # Load button (main action) - Enhanced primary button
        self.load_btn = PrimaryButton(
            actions_frame,
            text="🔥 LOAD HAND",
            command=self._load_selected_hand,
            theme_manager=self.theme,
        )
        self.load_btn.grid(row=0, column=0, sticky="ew", pady=5)

        # Enhanced button handles its own styling

        # Playback controls
        controls_frame = ttk.Frame(actions_frame)
        controls_frame.grid(row=1, column=0, sticky="ew", pady=5)
        controls_frame.grid_columnconfigure(1, weight=1)

        # Enhanced buttons handle their own styling

        # Enhanced secondary buttons for controls
        self.next_btn = SecondaryButton(
            controls_frame,
            text="Next →",
            command=self._next_enhanced_rpgw_action,  # Use Enhanced RPGW method
            theme_manager=self.theme,
        )
        self.next_btn.grid(row=0, column=0, padx=(0, 5))

        self.auto_btn = SecondaryButton(
            controls_frame,
            text="Auto",
            command=self._toggle_enhanced_rpgw_auto,  # Use Enhanced RPGW method
            theme_manager=self.theme,
        )
        self.auto_btn.grid(row=0, column=1, padx=5)

        self.reset_btn = SecondaryButton(
            controls_frame,
            text="Reset",
            command=self._reset_enhanced_rpgw_hand,  # Use Enhanced RPGW method
            theme_manager=self.theme,
        )
        self.reset_btn.grid(row=0, column=2, padx=(5, 0))

        # Enhanced buttons handle their own styling

        # Status text
        status_frame = ttk.LabelFrame(filters_frame, text="Status", padding=5)
        status_frame.grid(row=3, column=0, sticky="nsew")
        status_frame.grid_columnconfigure(0, weight=1)
        status_frame.grid_rowconfigure(0, weight=1)

        fonts = self.theme.get_fonts()
        small_font = fonts.get("small", ("Consolas", 16))
        status_height = self.theme.get_dimensions()["text_height"]["large"]
        self.status_text = tk.Text(
            status_frame, height=status_height, wrap=tk.WORD, font=small_font
        )
        self.status_text.grid(row=0, column=0, sticky="nsew")

        # Apply theme colors to status text
        try:
            self.status_text.configure(
                bg=theme.get("panel.bg", "#111827"),
                fg=theme.get("panel.fg", "#E5E7EB"),
                insertbackground=theme.get("panel.fg", "#E5E7EB"),
                highlightbackground=theme.get("panel.border", "#1F2937"),
                highlightcolor=theme.get("a11y.focusRing", "#22D3EE"),
            )
        except Exception:
            pass

        # Enhanced RPGW Controls
        rpgw_frame = ttk.LabelFrame(actions_frame, text="🎮 Enhanced RPGW Controls", padding=5)
        rpgw_frame.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        rpgw_frame.grid_columnconfigure(1, weight=1)

        # Next Action button for Enhanced RPGW
        self.rpgw_next_btn = SecondaryButton(
            rpgw_frame,
            text="▶ Next Action",
            command=self._next_enhanced_rpgw_action,
            theme_manager=self.theme,
        )
        self.rpgw_next_btn.grid(row=0, column=0, padx=(0, 5))

        # Reset button for Enhanced RPGW
        self.rpgw_reset_btn = SecondaryButton(
            rpgw_frame,
            text="↩ Reset Hand",
            command=self._reset_enhanced_rpgw_hand,
            theme_manager=self.theme,
        )
        self.rpgw_reset_btn.grid(row=0, column=1, padx=5)

        # Progress display for Enhanced RPGW
        self.rpgw_progress_label = ttk.Label(rpgw_frame, text="No hand loaded")
        self.rpgw_progress_label.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(5, 0))

        # Enhanced buttons handle their own styling

    def _create_poker_table_section(self):
        """Create poker table using Enhanced RPGW (right column)."""
        # Get theme colors for poker table
        theme = self.theme.get_theme()

        table_frame = ttk.LabelFrame(self, text="♠️ Enhanced Poker Table", padding=5)
        table_frame.grid(row=0, column=1, sticky="nsew", padx=(2.5, 5), pady=5)
        table_frame.grid_columnconfigure(0, weight=1)
        table_frame.grid_rowconfigure(0, weight=1)

        # Apply theme colors to table frame
        try:
            table_frame.configure(
                background=theme.get("panel.bg", "#111827"),
                foreground=theme.get("panel.sectionTitle", "#C7D2FE"),
            )
        except Exception:
            pass

        # Create Enhanced RPGW directly in the table frame
        self._setup_enhanced_rpgw(table_frame)

    def _setup_enhanced_rpgw(self, parent_frame):
        """Set up the Enhanced RPGW with poker table display."""
        # Get the actual frame dimensions for proper sizing
        parent_frame.update_idletasks()
        frame_width = parent_frame.winfo_width()
        frame_height = parent_frame.winfo_height()
        
        # Use frame dimensions instead of screen dimensions for better integration
        table_width = max(800, frame_width - 20)  # Leave 10px padding on each side
        table_height = max(600, frame_height - 20)
        
        # Calculate card size based on table dimensions
        card_width = max(40, int(table_width * 0.035))  # ~3.5% of table width
        card_height = int(card_width * 1.45)  # Standard card aspect ratio
        
        print(f"🎯 Enhanced RPGW: Frame {frame_width}x{frame_height}, Table {table_width}x{table_height}")
        print(f"🎯 Enhanced RPGW: Card size {card_width}x{card_height}")
        
        # Create canvas infrastructure with proper sizing
        self.canvas_manager = CanvasManager(parent_frame)
        
        # Configure canvas size to fit the frame
        self.canvas_manager.canvas.configure(width=table_width, height=table_height)
        
        self.layer_manager = LayerManager(
            self.canvas_manager.canvas,
            self.canvas_manager.overlay
        )
        
        # Create poker table components with proper sizing
        self.table_components = [
            TableFelt(),           # Background felt
            Seats(),              # Player seats with cards, stacks, names  
            Community(),          # Community cards
            BetDisplay(),         # Current bet amounts
            PotDisplay(),         # Pot amount display
            DealerButton(),       # Dealer button
            ActionIndicator(),    # Highlight acting player
        ]
        
        # Create rendering pipeline
        self.renderer_pipeline = RendererPipeline(
            self.canvas_manager,
            self.layer_manager,
            self.table_components
        )
        
        # Grid canvas to fill the frame with proper padding
        self.canvas_manager.canvas.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        parent_frame.grid_columnconfigure(0, weight=1)
        parent_frame.grid_rowconfigure(0, weight=1)
        
        # Store dimensions for state management
        self.table_width = table_width
        self.table_height = table_height
        self.card_width = card_width
        self.card_height = card_height
        
        # Initialize Enhanced RPGW state
        self._setup_enhanced_rpgw_state()
        
        # Refresh widget to ensure proper sizing
        self._refresh_enhanced_rpgw_widget()
        
        print("🎨 Enhanced RPGW poker table components ready")

    def _setup_enhanced_rpgw_state(self):
        """Initialize state management for the Enhanced RPGW."""
        # Initialize display state for the poker table
        self.display_state = {
            'table': {
                'width': self.table_width,
                'height': self.table_height
            },
            'pot': {
                'amount': 0.0,
                'side_pots': []
            },
            'seats': [],
            'board': [],
            'dealer': {
                'position': 0
            },
            'action': {
                'current_player': -1,
                'action_type': None,
                'amount': 0.0,
                'highlight': False
            },
            'replay': {
                'active': False,
                'current_action': 0,
                'total_actions': 0,
                'description': "No hand loaded"
            }
        }
        
        print("🎯 Enhanced RPGW state management ready")

    def _setup_event_subscriptions(self):
        """Subscribe to relevant events."""
        # Subscribe to review:load events as per architecture doc
        self.event_bus.subscribe(
            self.event_bus.topic(self.session_id, "review:load"),
            self._handle_load_hand_event,
        )

    def _refresh_hands_list(self):
        """Refresh the hands list based on current filters - prioritize GTO hands for PPSM."""
        # Check collection selection
        collection = getattr(self, 'collection_var', None)
        selected_collection = collection.get() if collection else "🤖 GTO Hands"
        
        # Load hands based on selection
        if selected_collection == "🤖 GTO Hands" and hasattr(self, 'loaded_gto_hands') and self.loaded_gto_hands:
            hands = self.loaded_gto_hands
            hands_source = "GTO"
        else:
            # Repository hands (legendary hands)
            hands = self.hands_repository.get_filtered_hands()
            hands_source = "Repository"

        print(f"🎯 HandsReviewTab: Loading {len(hands)} hands from {hands_source}")

        # Dispatch to store - convert Hand objects to dict format if needed
        hands_for_store = []
        for hand in hands:
            if hasattr(hand, 'metadata'):  # Hand object
                hands_for_store.append({
                    'hand_id': hand.metadata.get('hand_id', 'Unknown'),
                    'players': hand.seats,
                    'pot_size': hand.metadata.get('pot_size', 0)
                })
            else:  # Already dict format
                hands_for_store.append(hand)
                
        self.store.dispatch({"type": SET_REVIEW_HANDS, "hands": hands_for_store})

        # Update UI display
        self.hands_listbox.delete(0, tk.END)
        for i, hand in enumerate(hands):
            try:
                if hasattr(hand, 'metadata'):  # Hand object
                    hand_id = hand.metadata.get('hand_id', f'GTO_Hand_{i+1}')
                    players_count = len(hand.seats) if hasattr(hand, 'seats') else 2
                    display_text = f"{hand_id} | {players_count}p | PPSM Ready"
                else:  # Dict format
                    hand_id = hand.get("hand_id", f"Hand_{i+1}")
                    players_count = len(hand.get("players", []))
                    pot_size = hand.get("pot_size", 0)
                    display_text = f"{hand_id} | {players_count}p | ${pot_size}"
                self.hands_listbox.insert(tk.END, display_text)
            except Exception as e:
                # Fallback display
                self.hands_listbox.insert(tk.END, f"Hand_{i+1} | PPSM")
                print(f"⚠️ Error displaying hand {i}: {e}")

        # Update collections - prioritize GTO hands
        gto_available = hasattr(self, 'loaded_gto_hands') and self.loaded_gto_hands
        if gto_available:
            collections = ["🤖 GTO Hands", "All Hands"] + list(
                self.hands_repository.get_collections().keys()
            )
        else:
            collections = ["All Hands"] + list(
                self.hands_repository.get_collections().keys()
            )
        self.collection_combo["values"] = collections

        # Update status with workflow guidance based on active source
        if hands_source == "GTO":
            self._update_status(
                f"🤖 GTO Library: {len(hands)} hands loaded for PPSM testing"
            )
        else:
            stats = self.hands_repository.get_stats()
            self._update_status(
                f"📊 Repository: {stats['total_hands']} total, {stats['filtered_hands']} filtered"
            )
        self._update_status(
            "👆 SELECT a hand from the list, then click 'LOAD HAND' to begin PPSM study"
        )
        
        # Refresh Enhanced RPGW widget to ensure proper sizing
        if hasattr(self, '_refresh_enhanced_rpgw_widget'):
            self._refresh_enhanced_rpgw_widget()

    def _on_theme_change(self):
        """Handle poker table theme change for Enhanced RPGW."""
        theme_name = self.theme_var.get()
        print(f"🎨 Enhanced RPGW: Switching to theme: {theme_name}")

        # Switch theme in the theme manager
        self.theme.set_profile(theme_name)

        # Update status to show theme change
        self._update_status(
            f"🎨 Switched to {theme_name} theme - Enhanced RPGW colors applied!"
        )

        # Force Enhanced RPGW refresh with new theme
        if hasattr(self, 'renderer_pipeline') and hasattr(self, 'display_state'):
            self._render_enhanced_rpgw_table()
            print(f"🎨 Enhanced RPGW: Re-rendered with {theme_name} theme")

        # Refresh widget sizing to ensure proper fit
        self._refresh_enhanced_rpgw_widget()

        # Update artistic theme introduction
        self._show_theme_intro(theme_name)

    def _show_theme_intro(self, theme_name):
        """Show artistic introduction for the selected theme with luxury museum placard styling."""
        # Get theme metadata from config-driven system
        metadata = self.theme.get_theme_metadata(theme_name)
        main_desc = metadata.get(
            "intro", "A unique poker table theme with its own distinctive character."
        )
        persona = metadata.get("persona", "")

        # Update the intro label with luxury styling
        self.theme_intro_label.config(state="normal")
        self.theme_intro_label.delete(1.0, tk.END)

        # Insert main description with elegant styling
        self.theme_intro_label.insert(tk.END, main_desc)

        # Add poker persona in italic gold if present
        if persona:
            self.theme_intro_label.insert(tk.END, "\n\n")
            persona_start = self.theme_intro_label.index(tk.INSERT)
            # Format persona with attribution
            persona_text = f"— {persona} style —"
            self.theme_intro_label.insert(tk.END, persona_text)
            persona_end = self.theme_intro_label.index(tk.INSERT)

            # Apply italic styling to persona
            self.theme_intro_label.tag_add("persona", persona_start, persona_end)
            fonts = self.theme.get_fonts()
            persona_font = fonts.get(
                "persona", fonts.get("intro", ("Georgia", 15, "italic"))
            )
            self.theme_intro_label.tag_config("persona", font=persona_font)

        self.theme_intro_label.config(state="disabled")

        # Apply DYNAMIC luxury museum placard styling based on current theme
        theme = self.theme.get_theme()

        # Dynamic theme-aware colors for museum placard
        # Use theme's panel colors but make them more luxurious
        base_bg = theme.get("panel.bg", "#1A1A1A")
        base_border = theme.get("panel.border", "#2A2A2A")
        accent_color = theme.get("table.inlay", theme.get("pot.badgeRing", "#D4AF37"))
        text_primary = theme.get("text.primary", "#F5F5DC")
        text_secondary = theme.get("text.secondary", "#E0E0C0")

        # Use hand-tuned JSON theme colors for perfect quality
        base_colors = self.theme.get_base_colors()

        # Use hand-tuned emphasis tokens for perfect theme-specific quality
        placard_bg = base_colors.get(
            "emphasis_bg_top", base_colors.get("felt", base_bg)
        )
        placard_border = base_colors.get(
            "emphasis_border", base_colors.get("rail", base_border)
        )
        text_color = base_colors.get(
            "emphasis_text", base_colors.get("text", text_primary)
        )
        persona_color = base_colors.get(
            "emphasis_accent_text", base_colors.get("accent", accent_color)
        )
        accent_glow = base_colors.get(
            "highlight", base_colors.get("metal", accent_color)
        )

        # Apply dynamic luxury styling
        self.theme_intro_label.config(
            bg=placard_bg,
            fg=text_color,
            insertbackground=text_color,
            selectbackground=accent_glow,
            selectforeground=base_colors.get("highlight_text", "#FFFFFF"),
        )

        # Style the placard frame with hand-tuned luxury border
        if hasattr(self, "placard_frame"):
            self.placard_frame.config(
                bg=placard_border,  # Hand-tuned theme border color
                relief="raised",
                borderwidth=2,  # Luxury feel
                highlightbackground=accent_glow,
                highlightcolor=accent_glow,
                highlightthickness=1,
            )

        # Apply theme-specific persona text color
        if persona:
            self.theme_intro_label.config(state="normal")
            self.theme_intro_label.tag_config("persona", foreground=persona_color)
            self.theme_intro_label.config(state="disabled")

    def _refresh_ui_colors(self):
        """Refresh Enhanced RPGW with new theme colors."""
        theme = self.theme.get_theme()
        print(f"🎨 Enhanced RPGW: Refreshing colors for {self.theme_var.get()} theme")

        # Update Enhanced RPGW canvas background with new theme
        if hasattr(self, "canvas_manager") and self.canvas_manager.canvas:
            # Update canvas background to match new theme
            self.canvas_manager.canvas.configure(
                bg=theme.get("table.felt", "#1E5B44")
            )
            print(f"🎨 Enhanced RPGW: Canvas background updated to {theme.get('table.felt', '#1E5B44')}")

        # Force Enhanced RPGW re-render with new theme
        if hasattr(self, 'renderer_pipeline') and hasattr(self, 'display_state'):
            self._render_enhanced_rpgw_table()
            print(f"🎨 Enhanced RPGW: Re-rendered with new theme colors")

        # Update enhanced buttons to refresh their theme
        for btn_name in ["load_btn", "next_btn", "auto_btn", "reset_btn"]:
            if hasattr(self, btn_name):
                btn = getattr(self, btn_name)
                if hasattr(btn, "refresh_theme"):
                    btn.refresh_theme()

        # Update artistic theme intro panel colors
        if hasattr(self, "theme_intro_label"):
            self._show_theme_intro(self.theme_var.get())

    def _on_library_type_change(self):
        """Handle library type change."""
        library_type = self.library_type.get()
        # TODO: Filter by library type
        self._refresh_hands_list()

    def _on_collection_change(self, event=None):
        """Handle collection selection change."""
        collection = self.collection_var.get()
        print(f"🎯 Collection changed to: {collection}")
        
        if collection == "🤖 GTO Hands":
            # GTO hands are handled in _refresh_hands_list()
            pass
        elif collection == "All Hands":
            self.hands_repository.set_filter(HandsFilter())  # Clear filter
        else:
            # TODO: Set filter for specific collection
            pass
        self._refresh_hands_list()

    def _on_hand_select(self, event):
        """Handle hand selection - prioritize GTO hands for PPSM."""
        selection = self.hands_listbox.curselection()
        if selection:
            index = selection[0]
            
            # Get hands from the same source as _refresh_hands_list
            collection = getattr(self, 'collection_var', None)
            selected_collection = collection.get() if collection else "🤖 GTO Hands"
            
            if selected_collection == "🤖 GTO Hands" and hasattr(self, 'loaded_gto_hands') and self.loaded_gto_hands:
                hands = self.loaded_gto_hands
                hands_source = "GTO"
            else:
                hands = self.hands_repository.get_filtered_hands()
                hands_source = "Repository"
                
            if index < len(hands):
                hand = hands[index]
                self._update_hand_details(hand)
                
                # Get hand ID based on format
                if hasattr(hand, 'metadata'):  # Hand object
                    hand_id = hand.metadata.get('hand_id', 'Unknown')
                else:  # Dict format
                    hand_id = hand.get("hand_id", "Unknown")
                    
                # Show that hand is selected and ready to load
                self._update_status(
                    f"✅ Selected: {hand_id} ({hands_source}) - Click 'LOAD HAND' to start PPSM study"
                )

    def _update_hand_details(self, hand_data):
        """Update the hand details display - works with both Hand objects and dicts."""
        self.details_text.delete(1.0, tk.END)
        
        try:
            # Handle both Hand objects and dict format
            if hasattr(hand_data, 'metadata'):  # Hand object
                hand_id = hand_data.metadata.get('hand_id', 'Unknown')
                small_blind = hand_data.metadata.get('small_blind', 5)
                big_blind = hand_data.metadata.get('big_blind', 10)
                players_count = len(hand_data.seats) if hasattr(hand_data, 'seats') else 0
                
                details = f"Hand ID: {hand_id}\\n"
                details += f"Players: {players_count}\\n"
                details += f"Blinds: ${small_blind}/${big_blind}\\n"
                details += f"Engine: PPSM Ready\\n"
                details += f"Source: GTO Dataset"
                
            else:  # Dict format
                hand_id = hand_data.get("hand_id", "Unknown")
                players = hand_data.get("players", [])
                pot_size = hand_data.get("pot_size", 0)
                small_blind = hand_data.get("small_blind", 5)
                big_blind = hand_data.get("big_blind", 10)
                
                details = f"Hand ID: {hand_id}\\n"
                details += f"Players: {len(players)}\\n"
                details += f"Pot: ${pot_size}\\n"
                details += f"Blinds: ${small_blind}/${big_blind}\\n"
                details += f"Source: Repository"
                
        except Exception as e:
            details = f"Hand details unavailable: {e}"
            
        self.details_text.insert(1.0, details)

    def _on_study_mode_change(self):
        """Handle study mode change."""
        mode = self.study_mode.get()
        self.store.dispatch({"type": SET_STUDY_MODE, "mode": mode})
        self._update_status(f"📚 Study mode: {mode}")

    def _apply_filters(self):
        """Apply current filter settings."""
        filter_criteria = HandsFilter()

        # Apply position filter
        if self.position_var.get() != "All":
            filter_criteria.positions = [self.position_var.get()]

        # Apply stack depth filter
        try:
            filter_criteria.min_stack_depth = (
                int(self.min_stack.get()) if self.min_stack.get() else None
            )
            filter_criteria.max_stack_depth = (
                int(self.max_stack.get()) if self.max_stack.get() else None
            )
        except ValueError:
            pass

        # Apply pot type filter
        if self.pot_type_var.get() != "All":
            filter_criteria.pot_type = self.pot_type_var.get()

        # Apply search text
        filter_criteria.search_text = self.search_var.get()

        # Set filter and refresh
        self.hands_repository.set_filter(filter_criteria)
        self.store.dispatch(
            {"type": SET_REVIEW_FILTER, "filter": filter_criteria.__dict__}
        )
        self._refresh_hands_list()

    def _load_selected_hand(self):
        """Load the selected hand for PPSM study."""
        selection = self.hands_listbox.curselection()
        if not selection:
            self._update_status("❌ Please select a hand to load")
            return

        index = selection[0]
        
        # Get hands from the same source as _refresh_hands_list
        collection = getattr(self, 'collection_var', None)
        selected_collection = collection.get() if collection else "🤖 GTO Hands"
        
        if selected_collection == "🤖 GTO Hands" and hasattr(self, 'loaded_gto_hands') and self.loaded_gto_hands:
            hands = self.loaded_gto_hands
            hands_source = "GTO"
        else:
            hands = self.hands_repository.get_filtered_hands()
            hands_source = "Repository"
            
        if index >= len(hands):
            return

        hand_data = hands[index]
        
        print(f"🎯 Loading {hands_source} hand for PPSM study...")

        # Publish load event as per architecture doc
        self.event_bus.publish(
            self.event_bus.topic(self.session_id, "review:load"), hand_data
        )

    def _handle_load_hand_event(self, hand_data):
        """Handle the review:load event."""
        try:
            hand_id = hand_data.get("metadata", {}).get("hand_id", "Unknown")
            self._update_status(f"🔄 Loading hand {hand_id}...")

            # Store hand data for reset functionality
            self.current_hand_data = hand_data

            # Load hand into Enhanced RPGW
            self._load_hand_into_enhanced_rpgw(hand_data)

            # Update Enhanced RPGW progress display
            if hasattr(self, 'hand_actions') and self.hand_actions:
                total_actions = len(self.hand_actions)
                self.rpgw_progress_label.config(
                    text=f"Hand loaded: {total_actions} actions"
                )
                print(f"🎯 Enhanced RPGW: Hand {hand_id} loaded with {total_actions} actions")
            else:
                self.rpgw_progress_label.config(text="No actions available")
                print(f"⚠️ Enhanced RPGW: Hand {hand_id} loaded but no actions found")

            # Update status
            self._update_status(f"✅ Hand {hand_id} loaded into Enhanced RPGW")

        except Exception as e:
            print(f"❌ Enhanced RPGW: Error loading hand: {e}")
            self._update_status(f"❌ Error loading hand: {e}")

    def _toggle_enhanced_rpgw_auto(self):
        """Toggle Enhanced RPGW auto-play mode."""
        if not hasattr(self, 'hand_actions') or not self.hand_actions:
            print("⚠️ Enhanced RPGW: No hand actions available for auto-play")
            return
        
        if not hasattr(self, 'auto_play_active'):
            self.auto_play_active = False
        
        self.auto_play_active = not self.auto_play_active
        
        if self.auto_play_active:
            print("🎬 Enhanced RPGW: Auto-play started")
            self.auto_btn.config(text="Stop Auto")
            self._run_enhanced_rpgw_auto_play()
        else:
            print("⏹️ Enhanced RPGW: Auto-play stopped")
            self.auto_btn.config(text="Auto")

    def _run_enhanced_rpgw_auto_play(self):
        """Run Enhanced RPGW auto-play using GameDirector."""
        if not hasattr(self, 'auto_play_active') or not self.auto_play_active:
            return
        
        if self.current_action_index >= len(self.hand_actions):
            self.auto_play_active = False
            self.auto_btn.config(text="Auto")
            print("✅ Enhanced RPGW: Auto-play complete")
            return
        
        # Use GameDirector for coordinated action execution
        if hasattr(self, 'game_director'):
            self.game_director.play()
            print("🎬 GameDirector: Auto-play started")
        else:
            # Fallback to manual execution
            self._next_enhanced_rpgw_action()
            self.after(1000, self._run_enhanced_rpgw_auto_play)

    def _reset_hand(self):
        """Reset the current hand."""
        if not self.current_session:
            self._update_status("⚠️  No active session to reset")
            return

        try:
            self.current_session.reset_session()
            self.session_active = True
            self._update_status("🔄 Hand reset to beginning")
        except Exception as e:
            self._update_status(f"❌ Error resetting hand: {e}")

    def _update_status(self, message: str):
        """Update the status display."""
        self.status_text.insert(tk.END, f"\n{message}")
        self.status_text.see(tk.END)

    def _on_store_change(self, state):
        """Handle store state changes for Enhanced RPGW rendering."""
        try:
            # Check if we have Enhanced RPGW state to update
            if hasattr(self, 'display_state') and 'enhanced_rpgw' in state:
                # Update local display state from store
                self.display_state.update(state['enhanced_rpgw'])
                
                # Re-render the table with updated state
                self._render_enhanced_rpgw_table()
                
                # Handle animation events
                if 'animation_event' in state.get('enhanced_rpgw', {}):
                    self._handle_enhanced_rpgw_animation_event(
                        state['enhanced_rpgw']['animation_event']
                    )
                    
                print("🔄 Enhanced RPGW: State updated from store")
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Store change handling error: {e}")

    def _handle_enhanced_rpgw_animation_event(self, animation_event):
        """Handle animation events from the store."""
        try:
            if animation_event.get('action') == 'clear_highlight':
                self._clear_enhanced_rpgw_highlight()
                print("🎬 Enhanced RPGW: Animation event processed")
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Animation event handling error: {e}")

    def _refresh_fonts(self):
        """Refresh fonts after theme changes."""
        fonts = self.theme.get_fonts()

        # Update listbox font
        if hasattr(self, "hands_listbox"):
            body_font = fonts.get("body", ("Consolas", 20))
            self.hands_listbox.configure(font=body_font)

        # Update text areas
        small_font = fonts.get("small", ("Consolas", 16))
        if hasattr(self, "details_text"):
            self.details_text.configure(font=small_font)
        if hasattr(self, "status_text"):
            self.status_text.configure(font=small_font)

        # Update theme intro label font (luxury serif)
        if hasattr(self, "theme_intro_label"):
            intro_font = fonts.get(
                "intro", fonts.get("body", ("Georgia", 16, "normal"))
            )
            self.theme_intro_label.configure(font=intro_font)
    
    def _start_update_loop(self):
        """Start the main update loop for GameDirector and EffectBus."""
        def update_loop():
            try:
                # Update GameDirector
                if hasattr(self, 'game_director'):
                    self.game_director.update()
                
                # Update EffectBus
                if hasattr(self, 'effect_bus'):
                    self.effect_bus.update()
                
                # Schedule next update (60 FPS)
                self.after(16, update_loop)
                
            except Exception as e:
                print(f"⚠️ Update loop error: {e}")
                # Continue update loop even if there's an error
                self.after(16, update_loop)
        
        # Start the update loop
        update_loop()
        print("🔄 Update loop started for GameDirector and EffectBus")
    
    def _setup_action_banner(self):
        """Setup ActionBanner and connect it to EffectBus events."""
        try:
            if ActionBanner:
                # Create ActionBanner at the top of the poker table section
                self.action_banner = ActionBanner(self)
                
                # Subscribe to EffectBus banner events
                if hasattr(self, 'event_bus'):
                    self.event_bus.subscribe("effect_bus:banner_show", self._handle_banner_event)

                # Subscribe to EffectBus animation events
                if hasattr(self, 'event_bus'):
                    self.event_bus.subscribe("effect_bus:animate", self._handle_effect_animate)
                    print("🎞️ Animation: Connected to EffectBus events")
                    print("🎭 ActionBanner: Connected to EffectBus events")
                else:
                    print("⚠️ ActionBanner: No event bus available")
            else:
                print("⚠️ ActionBanner: Not available, skipping setup")
                
        except Exception as e:
            print(f"⚠️ ActionBanner: Setup error: {e}")
    
    def _handle_banner_event(self, event_data):
        """Handle banner events from EffectBus."""
        try:
            if hasattr(self, 'action_banner'):
                message = event_data.get('message', '')
                banner_type = event_data.get('banner_type', 'info')
                duration_ms = event_data.get('duration_ms', 3000)
                
                self.action_banner.show_banner(message, banner_type, duration_ms)
                print(f"🎭 ActionBanner: Showing banner: {message}")
            else:
                print("⚠️ ActionBanner: Not available for banner event")
                
        except Exception as e:
            print(f"⚠️ ActionBanner: Banner event error: {e}")

        # Update enhanced button themes (handles both fonts and colors)
        enhanced_buttons = []
        if hasattr(self, "load_btn") and hasattr(self.load_btn, "refresh_theme"):
            enhanced_buttons.append(self.load_btn)
        if hasattr(self, "next_btn") and hasattr(self.next_btn, "refresh_theme"):
            enhanced_buttons.append(self.next_btn)
        if hasattr(self, "auto_btn") and hasattr(self.auto_btn, "refresh_theme"):
            enhanced_buttons.append(self.auto_btn)
        if hasattr(self, "reset_btn") and hasattr(self.reset_btn, "refresh_theme"):
            enhanced_buttons.append(self.reset_btn)

        for btn in enhanced_buttons:
            btn.refresh_theme()


    
    def _handle_effect_animate(self, payload):
        """Handle animation requests from EffectBus using ChipAnimations where possible."""
        try:
            name = (payload or {}).get("name")
            ms = int((payload or {}).get("ms", 300))
            if not getattr(self, "canvas_manager", None):
                return
            c = self.canvas_manager.canvas
            from ..tableview.components.chip_animations import ChipAnimations
            anim = ChipAnimations(self.theme_manager)
            pot_center = getattr(self, "pot_center", (self.width//2, self.height//2)) if hasattr(self, "width") else (200, 100)
            # Try to locate a hero seat for source position
            seats = self.display_state.get("seats", [])
            if seats:
                src_seat = seats[0]
                sx, sy = src_seat.get("x", 80), src_seat.get("y", 160)
            else:
                sx, sy = 80, 160

            if name == "chips_to_pot":
                anim.fly_chips_to_pot(c, sx, sy, pot_center[0], pot_center[1], amount=200, callback=None)
            elif name == "pot_to_winner":
                # Pick the winner seat roughly
                winner = None
                for seat in seats:
                    if not seat.get("folded"):
                        winner = seat; break
                wx, wy = (winner.get("x", 320), winner.get("y", 160)) if winner else (320, 160)
                anim.fly_pot_to_winner(c, pot_center[0], pot_center[1], wx, wy, callback=None)
        except Exception as e:
            print(f"⚠️ Animation handler error: {e}")


    def _style_theme_radio_buttons(self):
        """Apply theme-specific styling to radio buttons to eliminate default green highlights."""
        if not hasattr(self, "theme_radio_buttons"):
            return

        try:
            # Get current theme and highlight colors
            current_theme_name = self.theme.current() or "Forest Green Professional 🌿"
            theme = self.theme.get_theme()

            # Create a custom style for radio buttons
            style = ttk.Style()

            # Apply config-driven selection styling
            selection_styler = self.theme.get_selection_styler()
            if selection_styler:
                theme_id = self.theme.get_current_theme_id()
                selection_styler.apply_selection_styles(style, theme_id)

            # Get selection highlight colors (config-driven with legacy fallback)
            try:
                base_colors = self.theme.get_base_colors()
                selection_color = base_colors.get(
                    "highlight", base_colors.get("accent", "#D4AF37")
                )
                selection_glow = base_colors.get(
                    "metal", base_colors.get("accent", "#C9A34E")
                )
            except Exception:
                # Get selection highlight from config-driven system
                base_colors = self.theme.get_base_colors()
                selection_highlight = {
                    "color": base_colors.get(
                        "highlight", base_colors.get("accent", "#D4AF37")
                    )
                }
                selection_color = selection_highlight["color"]
                selection_glow = selection_highlight.get("glow", "#C9A34E")

            # Configure the radio button style with theme-specific colors
            style.configure(
                "Themed.TRadiobutton",
                background=theme.get("panel.bg", "#1F2937"),
                foreground=theme.get("panel.fg", "#E5E7EB"),
                focuscolor=selection_color,
            )

            # Configure the selection/active state colors
            style.map(
                "Themed.TRadiobutton",
                background=[
                    ("active", theme.get("panel.bg", "#1F2937")),
                    ("selected", theme.get("panel.bg", "#1F2937")),
                ],
                foreground=[
                    ("active", theme.get("panel.fg", "#E5E7EB")),
                    ("selected", theme.get("panel.fg", "#E5E7EB")),
                ],
                indicatorcolor=[
                    ("selected", selection_color),
                    ("active", selection_glow),
                    ("!selected", theme.get("panel.border", "#374151")),
                ],
            )

            # Apply the custom style to all radio buttons
            for radio_btn in self.theme_radio_buttons:
                if radio_btn.winfo_exists():
                    radio_btn.configure(style="Themed.TRadiobutton")

        except Exception as e:
            # Fallback styling if custom styling fails
            print(f"⚠️ Radio button styling failed: {e}")
            pass

    def _on_theme_change(self):
        """Handle theme change from radio buttons."""
        try:
            selected_theme = self.theme_var.get()
            if selected_theme:
                print(f"🎨 Theme changed to: {selected_theme}")

                # Set the theme using the theme manager
                self.theme.set_profile(selected_theme)

                # Update all UI colors including radio button styling
                self._refresh_ui_colors()

                # Update the theme introduction display
                self._show_theme_intro(selected_theme)

                # Force a table render with new theme
                if hasattr(self, "renderer_pipeline") and self.renderer_pipeline:
                    self.after_idle(
                        lambda: self.renderer_pipeline.render_once(
                            self.store.get_state()
                        )
                    )

        except Exception as e:
            print(f"⚠️ Theme change error: {e}")

    def _next_action(self):
        """Advance to the next action in the hand."""
        print("🎯 NEXT_ACTION: Button clicked!")

        # Debug session state
        print(f"🎯 NEXT_ACTION: session_active={self.session_active}")
        print(f"🎯 NEXT_ACTION: current_session={self.current_session}")

        if not self.session_active or not self.current_session:
            self._update_status(
                "⚠️ No hand loaded. Please select and load a hand first."
            )
            return

        try:
            # Debug session state
            print(f"🎯 NEXT_ACTION: Session type: {type(self.current_session)}")
            print(
                f"🎯 NEXT_ACTION: Session active: {getattr(self.current_session, 'session_active', 'N/A')}"
            )

            # Check if session is complete first
            if (
                hasattr(self.current_session, "decision_engine")
                and self.current_session.decision_engine.is_session_complete()
            ):
                self._update_status("🏁 Hand complete - no more actions")
                return

            # Execute next action through the session (using the correct method for hands review)
            print("🎯 NEXT_ACTION: Calling step_forward...")
            result = self.current_session.step_forward()
            print(f"🎯 NEXT_ACTION: Result: {result}")

            if result:
                # Get explanation if available
                explanation = getattr(
                    self.current_session,
                    "current_decision_explanation",
                    "Action executed",
                )
                self._update_status(f"▶️ {explanation}")

                # PPSM should automatically update the poker table display
                # Force a render to ensure UI is updated
                print("🎯 NEXT_ACTION: Forcing UI update...")
                self.after_idle(
                    lambda: self.renderer_pipeline.render_once(self.store.get_state())
                )
            else:
                self._update_status("🏁 Hand complete - no more actions")
        except Exception as e:
            self._update_status(f"❌ Error advancing hand: {e}")
            print(f"🎯 NEXT_ACTION: Exception: {e}")
            import traceback

            traceback.print_exc()

    def _reset_hand(self):
        """Reset the current hand to the beginning."""
        if not self.session_active or not self.current_session:
            self._update_status(
                "⚠️ No hand loaded. Please select and load a hand first."
            )
            return

        try:
            # Reset the session
            if hasattr(self.current_session, "reset_session"):
                self.current_session.reset_session()
                self._update_status("🔄 Hand reset to beginning")

                # Force a render to show initial state
                self.after_idle(
                    lambda: self.renderer_pipeline.render_once(self.store.get_state())
                )
            else:
                # Fallback - reload the current hand
                self._update_status("🔄 Reloading hand...")
                if hasattr(self, "last_loaded_hand"):
                    self._handle_load_hand_event(self.last_loaded_hand)
                else:
                    self._update_status("⚠️ No hand to reset")
        except Exception as e:
            self._update_status(f"❌ Error resetting hand: {e}")

    def on_show(self):
        """Called when tab is shown - refresh display."""
        if hasattr(self, "renderer_pipeline"):
            state = self.store.get_state()
            self.renderer_pipeline.render_once(state)

    def dispose(self):
        """Clean up when tab is closed."""
        # Clean up PPSM session if active
        if self.current_session:
            self.session_active = False
            self.current_session = None
        self.services.dispose_session(self.session_id)

    def _load_gto_hands(self):
        """Load GTO hands for PPSM testing."""
        try:
            import json
            import os
            
            gto_hands_file = "gto_hands.json"
            print(f"🔍 Looking for GTO hands file: {gto_hands_file}")
            
            if os.path.exists(gto_hands_file):
                print(f"📂 Found GTO hands file, loading...")
                with open(gto_hands_file, 'r') as f:
                    hands_data = json.load(f)
                    
                print(f"📊 Raw GTO hands data: {len(hands_data)} hands")
                    
                # Convert to Hand objects
                self.loaded_gto_hands = []
                for i, hand_data in enumerate(hands_data):
                    try:
                        hand = Hand(**hand_data)  # Create proper Hand object
                        self.loaded_gto_hands.append(hand)
                    except Exception as e:
                        print(f"⚠️ Error creating Hand object for hand {i}: {e}")
                        # Fallback: store as dict
                        self.loaded_gto_hands.append(hand_data)
                        
                print(f"✅ Loaded {len(self.loaded_gto_hands)} GTO hands for PPSM testing")
            else:
                print(f"⚠️ GTO hands file not found: {gto_hands_file}")
                self.loaded_gto_hands = []
                
        except Exception as e:
            print(f"⚠️ Error loading GTO hands: {e}")
            self.loaded_gto_hands = []

    def _load_hand_into_enhanced_rpgw(self, hand_data):
        """Load hand data into Enhanced RPGW using new architecture."""
        try:
            # Store the hand data for reference
            self.current_hand_data = hand_data
            
            # Flatten hand actions for step-by-step replay
            self.hand_actions = self._flatten_hand_for_replay(hand_data)
            
            # Reset action index
            self.current_action_index = 0
            
            # Create display state from hand data
            new_display_state = self._create_display_state_from_hand(hand_data)
            
            # Update the existing display state with new data
            self.display_state.update(new_display_state)
            
            # Dispatch LOAD_REVIEW_HAND action to store
            self.store.dispatch({
                "type": "LOAD_REVIEW_HAND",
                "hand_data": hand_data,
                "flattened_actions": self.hand_actions
            })
            
            # Update progress display
            if self.hand_actions:
                progress_text = f"Action {self.current_action_index + 1}/{len(self.hand_actions)}"
                self.rpgw_progress_label.config(text=progress_text)
                # Enable next button
                self.rpgw_next_btn.config(state="normal")
                
                # Setup GameDirector for this hand
                if hasattr(self, 'game_director'):
                    self.game_director.set_total_steps(len(self.hand_actions))
                    self.game_director.set_advance_callback(self._execute_action_at_index)
                    print(f"🎬 GameDirector: Configured for {len(self.hand_actions)} actions")
            
            # Render the table
            self._render_enhanced_rpgw_table()
            
            # Refresh widget to ensure proper sizing
            self._refresh_enhanced_rpgw_widget()
            
            print(f"✅ Enhanced RPGW: Hand loaded with {len(self.hand_actions)} actions")
            
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Error loading hand: {e}")

    def _create_display_state_from_hand(self, hand_data):
        """Create display state from hand data for Enhanced RPGW."""
        try:
            # Extract basic hand information - GTO hands use 'seats' not 'players'
            seats = hand_data.get('seats', [])
            small_blind = hand_data.get('metadata', {}).get('small_blind', 5)
            big_blind = hand_data.get('metadata', {}).get('big_blind', 10)
            
            # Create initial display state with actual table dimensions
            display_state = {
                'table': {
                    'width': getattr(self, 'table_width', 800),
                    'height': getattr(self, 'table_height', 600),
                    'theme': 'luxury_noir'  # Default theme
                },
                'pot': {
                    'amount': 0,
                    'position': (400, 300)
                },
                'seats': [],
                'board': [],
                'dealer': {'position': 0},
                'action': {'type': None, 'player': None, 'amount': 0},
                'replay': {'current_step': 0, 'total_steps': 0}
            }
            
            # Set up seats from GTO hand data
            for i, seat in enumerate(seats):
                player_uid = seat.get('player_uid', f'player_{i}')
                name = seat.get('display_name', f'Player {i+1}')
                starting_stack = seat.get('starting_stack', 1000)
                
                # Calculate seat position (simplified for now)
                angle = (2 * 3.14159 * i) / len(seats)
                radius = 200
                x = 400 + int(radius * math.cos(angle))
                y = 300 + int(radius * math.sin(angle))
                
                # Get hole cards for this player from metadata
                hole_cards = hand_data.get('metadata', {}).get('hole_cards', {}).get(player_uid, [])
                
                seat_data = {
                    'player_uid': player_uid,
                    'name': name,
                    'starting_stack': starting_stack,
                    'current_stack': starting_stack,
                    'current_bet': 0,
                    'cards': hole_cards,  # Populate with actual hole cards
                    'folded': False,
                    'all_in': False,
                    'acting': False,
                    'position': i
                }
                
                # Set initial blinds based on seat order
                if i == 0:  # Small blind
                    seat_data['current_bet'] = small_blind
                    seat_data['current_stack'] -= small_blind
                elif i == 1:  # Big blind
                    seat_data['current_bet'] = big_blind
                    seat_data['current_stack'] -= big_blind
                
                display_state['seats'].append(seat_data)
            
            print(f"🎯 Enhanced RPGW: Created display state with {len(display_state['seats'])} seats")
            for seat in display_state['seats']:
                print(f"  🪑 {seat['name']}: {seat['cards']} (stack: {seat['current_stack']}, bet: {seat['current_bet']})")
            
            return display_state
            
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Error creating display state: {e}")
            return {}

    def _flatten_hand_for_replay(self, hand):
        """Produce a list of 'steps' to drive the Enhanced RPGW UI."""
        steps = []

        # Synthesize: deal hole cards
        holes = (hand.get("metadata", {}) or {}).get("hole_cards", {}) or {}
        steps.append({
            "type": "DEAL_HOLE",
            "desc": "🃏 Deal hole cards",
            "payload": {"hole_cards": holes},
        })

        streets = hand.get("streets", {}) or {}
        # Keep deterministic street order
        for street_name in ("PREFLOP", "FLOP", "TURN", "RIVER"):
            if street_name not in streets:
                continue
            s = streets[street_name] or {}
            actions = s.get("actions", []) or []
            board = s.get("board", []) or []

            # If board present, add board-deal step
            if street_name != "PREFLOP" and board:
                steps.append({
                    "type": "DEAL_BOARD",
                    "desc": f"🂠 Deal {street_name} board: {', '.join(board)}",
                    "payload": {"street": street_name, "board": board},
                })

            for a in actions:
                # Handle different action types
                action_type = a.get("action", "UNKNOWN")
                actor = a.get("actor_uid", "Unknown")
                amount = a.get("amount", 0)
                
                if action_type == "POST_BLIND":
                    desc = f"{street_name}: {actor} → {action_type} {amount}"
                elif action_type in ["BET", "RAISE", "CALL"]:
                    desc = f"{street_name}: {actor} → {action_type} {amount}"
                elif action_type == "CHECK":
                    desc = f"{street_name}: {actor} → {action_type}"
                elif action_type == "FOLD":
                    desc = f"{street_name}: {actor} → {action_type}"
                else:
                    desc = f"{street_name}: {actor} → {action_type} {amount if amount else ''}"
                
                steps.append({
                    "type": action_type,
                    "desc": desc,
                    "payload": {"street": street_name, **a},
                })

        # Terminal step
        steps.append({"type": "END_HAND", "desc": "✅ End of hand", "payload": {}})
        return steps

    def _render_enhanced_rpgw_table(self):
        """Render the Enhanced RPGW poker table using the component pipeline."""
        try:
            # Use state-driven rendering pipeline
            self.renderer_pipeline.render_once(self.display_state)
            print("🎨 Enhanced RPGW: Table rendered successfully")
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Render error: {e}")

    def _next_enhanced_rpgw_action(self):
        """Execute next action using proper Store-based architecture."""
        try:
            # Check if we have actions to execute
            if not hasattr(self, 'hand_actions') or not self.hand_actions:
                print("⚠️ Enhanced RPGW: No hand actions available")
                return
            
            # Check if we can go to next action
            if self.current_action_index >= len(self.hand_actions) - 1:
                print("⚠️ Enhanced RPGW: Already at last action")
                return
            
            # Move to next action
            self.current_action_index += 1
            action = self.hand_actions[self.current_action_index]
            
            # Execute the action to update display state
            self._execute_action_step(action)
            
            # Update progress display
            progress_text = f"Action {self.current_action_index + 1}/{len(self.hand_actions)}"
            if hasattr(self, 'rpgw_progress_label'):
                self.rpgw_progress_label.config(text=progress_text)
            
            # Dispatch action to store for state management
            self.store.dispatch({
                "type": "NEXT_REVIEW_ACTION"
            })
            
            print(f"🎬 Enhanced RPGW: Executed action {self.current_action_index}: {action.get('type', 'UNKNOWN')}")
            
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Error executing next action: {e}")
    
    def _execute_action_step(self, action):
        """Execute a single action step and update display state."""
        try:
            action_type = action.get('type', 'UNKNOWN')
            payload = action.get('payload', {})
            
            # Get player name for effects
            actor_uid = payload.get('actor_uid', 'Unknown')
            player_name = None
            for seat in self.display_state['seats']:
                if seat['player_uid'] == actor_uid:
                    player_name = seat.get('name', actor_uid)
                    break
            

            # Update acting highlight: set only the actor as acting
            try:
                for seat in self.display_state.get('seats', []):
                    seat['acting'] = (seat.get('player_uid') == actor_uid)
            except Exception:
                pass
            if action_type == "DEAL_HOLE":
                # Hole cards are already loaded in initial state
                print(f"🃏 Enhanced RPGW: Hole cards dealt")
                
                # Add deal sound and animation effects
                if hasattr(self, 'effect_bus'):
                    self.effect_bus.add_poker_action_effects("DEAL_HOLE", player_name)
                
            elif action_type == "DEAL_BOARD":
                street = payload.get('street', 'UNKNOWN')
                board = payload.get('board', [])
                self.display_state['board'] = board
                print(f"🂠 Enhanced RPGW: Dealt {street} board: {board}")
                
                # Add deal sound and animation effects
                if hasattr(self, 'effect_bus'):
                    self.effect_bus.add_poker_action_effects("DEAL_BOARD", player_name)
                
            elif action_type in ["BET", "RAISE", "CALL", "CHECK", "FOLD"]:
                amount = payload.get('amount', 0)
                
                # Update the appropriate seat's bet and stack
                for seat in self.display_state['seats']:
                    if seat['player_uid'] == actor_uid:
                        if action_type in ["BET", "RAISE"]:
                            # For BET/RAISE, amount is the total bet
                            seat['current_bet'] = amount
                            seat['current_stack'] = seat['starting_stack'] - amount
                        elif action_type == "CALL":
                            # For CALL, amount is the total bet to match
                            seat['current_bet'] = amount
                            seat['current_stack'] = seat['starting_stack'] - amount
                        elif action_type == "CHECK":
                            # CHECK doesn't change bet or stack
                            pass
                        elif action_type == "FOLD":
                            seat['folded'] = True
                            # Folded players keep their current bet
                        
                        # Set acting flag for highlighting
                        seat['acting'] = True
                        break
                
                # Clear acting flag from other seats
                for seat in self.display_state['seats']:
                    if seat['player_uid'] != actor_uid:
                        seat['acting'] = False
                
                # Update pot amount
                if action_type in ["BET", "RAISE", "CALL"]:
                    total_pot = sum(seat['current_bet'] for seat in self.display_state['seats'])
                    self.display_state['pot']['amount'] = total_pot
                
                print(f"🎯 Enhanced RPGW: {actor_uid} {action_type} {amount if amount else ''}")
                
                # Add action sound and animation effects
                if hasattr(self, 'effect_bus'):
                    self.effect_bus.add_poker_action_effects(action_type, player_name)
                
                # Show action banner for immediate visual feedback
                if hasattr(self, 'action_banner'):
                    amount = payload.get('amount', 0)
                    self.action_banner.show_poker_action(action_type, player_name, amount)
                
            elif action_type == "POST_BLIND":
                amount = payload.get('amount', 0)
                
                # Update seat bet and stack for blind posting
                for seat in self.display_state['seats']:
                    if seat['player_uid'] == actor_uid:
                        seat['current_bet'] = amount
                        seat['current_stack'] -= amount
                        break
                
                print(f"💰 Enhanced RPGW: {actor_uid} posted blind: {amount}")
                
                # Add blind posting effects
                if hasattr(self, 'effect_bus'):
                    self.effect_bus.add_poker_action_effects("POST_BLIND", player_name)
            
            # Re-render the table with updated state
            self._render_enhanced_rpgw_table()
            
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Error executing action step: {e}")
    
    def _execute_action_at_index(self, action_index: int):
        """Execute action at specific index - called by GameDirector."""
        try:
            if 0 <= action_index < len(self.hand_actions):
                self.current_action_index = action_index
                action = self.hand_actions[action_index]
                
                # Execute the action
                self._execute_action_step(action)
                
                # Update progress display
                progress_text = f"Action {self.current_action_index + 1}/{len(self.hand_actions)}"
                if hasattr(self, 'rpgw_progress_label'):
                    self.rpgw_progress_label.config(text=progress_text)
                
                print(f"🎬 GameDirector: Executed action at index {action_index}")
            else:
                print(f"⚠️ GameDirector: Invalid action index {action_index}")
                
        except Exception as e:
            print(f"⚠️ GameDirector: Error executing action at index {action_index}: {e}")

    def _prev_enhanced_rpgw_action(self):
        """Execute previous action using proper Store-based architecture."""
        try:
            # Check if we have actions to execute
            if not hasattr(self, 'hand_actions') or not self.hand_actions:
                print("⚠️ Enhanced RPGW: No hand actions available")
                return
            
            # Check if we can go to previous action
            if self.current_action_index <= 0:
                print("⚠️ Enhanced RPGW: Already at first action")
                return
            
            # Move to previous action
            self.current_action_index -= 1
            action = self.hand_actions[self.current_action_index]
            
            # Execute the action to update display state
            self._execute_action_step(action)
            
            # Update progress display
            progress_text = f"Action {self.current_action_index + 1}/{len(self.hand_actions)}"
            if hasattr(self, 'rpgw_progress_label'):
                self.rpgw_progress_label.config(text=progress_text)
            
            # Dispatch action to store for state management
            self.store.dispatch({
                "type": "PREV_REVIEW_ACTION"
            })
            
            print(f"🎬 Enhanced RPGW: Executed previous action {self.current_action_index}: {action.get('type', 'UNKNOWN')}")
            
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Error executing previous action: {e}")

    def _reset_enhanced_rpgw_hand(self):
        """Reset Enhanced RPGW to beginning of hand."""
        try:
            # Reset action index
            self.current_action_index = 0
            
            # Recreate initial display state from hand data
            if hasattr(self, 'current_hand_data'):
                self.display_state = self._create_display_state_from_hand(self.current_hand_data)
                
                # Update progress display
                if hasattr(self, 'rpgw_progress_label'):
                    self.rpgw_progress_label.config(text="Action 1/" + str(len(self.hand_actions)))
                
                # Re-render the table
                self._render_enhanced_rpgw_table()
                
                print("↩️ Enhanced RPGW: Reset to beginning of hand")
            else:
                print("⚠️ Enhanced RPGW: No hand data available for reset")
            
            # Dispatch action to store for state management
            self.store.dispatch({
                "type": "RESET_REVIEW_HAND"
            })
            
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Error resetting hand: {e}")

    def _execute_enhanced_rpgw_action(self, action):
        """Execute action and update Enhanced RPGW state with rich UI/UX features."""
        # REMOVED: This method should not contain business logic
        # Business logic should be in PPSM or Store reducers
        # UI should only dispatch actions and render state
        pass

    def _play_enhanced_rpgw_sound(self, sound_type):
        """Play sound effects for Enhanced RPGW actions."""
        try:
            if hasattr(self, 'sound_manager') and self.sound_manager:
                # Map sound types to sound manager events
                sound_mapping = {
                    'card_deal': 'card_deal',
                    'chip_bet': 'chip_bet',
                    'player_bet': 'player_action_bet',
                    'player_call': 'player_action_call',
                    'player_check': 'player_action_check',
                    'player_fold': 'player_action_fold',
                    'hand_end': 'hand_end'
                }
                
                event_name = sound_mapping.get(sound_type, sound_type)
                self.sound_manager.play(event_name)
                print(f"🔊 Enhanced RPGW: Playing {sound_type} sound")
            else:
                print(f"🔇 Enhanced RPGW: No sound manager available for {sound_type}")
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Sound error for {sound_type}: {e}")

    def _schedule_enhanced_rpgw_animation(self):
        """Schedule animation effects using event-driven system."""
        try:
            # Use event bus instead of direct UI timing (architectural compliance)
            if hasattr(self, 'event_bus'):
                self.event_bus.publish(
                    self.event_bus.topic(self.session_id, "enhanced_rpgw:animation"),
                    {
                        "type": "SCHEDULE_HIGHLIGHT_CLEAR",
                        "delay_ms": 200,
                        "action": "clear_highlight"
                    }
                )
                print(f"🎬 Enhanced RPGW: Scheduled animation via event bus")
            else:
                print(f"⚠️ Enhanced RPGW: No event bus available for animation")
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Animation scheduling error: {e}")

    def _clear_enhanced_rpgw_highlight(self):
        """Clear player highlighting after animation."""
        try:
            if hasattr(self, 'display_state') and 'action' in self.display_state:
                self.display_state['action']['highlight'] = False
                # Re-render to show cleared highlight
                self._render_enhanced_rpgw_table()
                print(f"🎬 Enhanced RPGW: Cleared action highlight")
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Highlight clear error: {e}")

    def _refresh_enhanced_rpgw_widget(self):
        """Refresh the Enhanced RPGW widget to ensure proper sizing and fit."""
        try:
            if hasattr(self, 'canvas_manager') and self.canvas_manager:
                # Force canvas to update its geometry
                self.canvas_manager.canvas.update_idletasks()
                
                # Get current frame dimensions
                parent_frame = self.canvas_manager.canvas.master
                frame_width = parent_frame.winfo_width()
                frame_height = parent_frame.winfo_height()
                
                # Recalculate table dimensions
                table_width = max(800, frame_width - 20)
                table_height = max(600, frame_height - 20)
                
                # Update canvas size
                self.canvas_manager.canvas.configure(width=table_width, height=table_height)
                
                # Update stored dimensions
                self.table_width = table_width
                self.table_height = table_height
                
                # Update display state
                if hasattr(self, 'display_state'):
                    self.display_state['table']['width'] = table_width
                    self.display_state['table']['height'] = table_height
                
                # Re-render with new dimensions
                self._render_enhanced_rpgw_table()
                
                print(f"🔄 Enhanced RPGW: Widget refreshed to {table_width}x{table_height}")
        except Exception as e:
            print(f"⚠️ Enhanced RPGW: Widget refresh error: {e}")
