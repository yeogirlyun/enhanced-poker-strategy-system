## Hands Review — Problem Report
[See root causes and fixes as discussed in chat; this file will be created by the command]
