import re
from hand_model import Hand, HandMetadata, Seat, Action, Street, StreetState, Pot, PotShare, ShowdownEntry

def canon_uid(name: str | None, idx: int | None) -> str:
    if name:
        return re.sub(r"\s+", "", name).lower()
    if idx is not None:
        return f"p{idx+1}"
    raise ValueError("Cannot canonize UID without name or index")

def convert_legendary(source: dict) -> Hand:
    seats = []
    for i, p in enumerate(source.get("players", [])):
        uid = canon_uid(p.get("id") or p.get("name"), i)
        seats.append(Seat(seat_no=i+1, player_uid=uid, display_name=p.get("name",""), starting_stack=int(p.get("stack",0))))

    metadata = HandMetadata(
        table_id=source.get("table_id",""),
        hand_id=source.get("hand_id",""),
        small_blind=int(source.get("small_blind", 50)),
        big_blind=int(source.get("big_blind", 100)),
        ante=int(source.get("ante", 0)),
        button_seat_no=source.get("button_seat_no")
    )

    streets = {Street.PREFLOP: StreetState(), Street.FLOP: StreetState(),
               Street.TURN: StreetState(), Street.RIVER: StreetState()}

    order_counter = 0
    def add_action(street, actor, kind, amount=0, to=None, **kw):
        nonlocal order_counter
        order_counter += 1
        streets[street].actions.append(Action(
            order=order_counter,
            street=street,
            actor_uid=canon_uid(actor, None) if actor else None,
            action=kind,
            amount=int(amount or 0),
            to_amount=to,
            **kw
        ))

    # Here populate streets[...] with actual actions from source if needed

    hand = Hand(metadata=metadata, seats=seats, streets=streets)
    return hand
