from dataclasses import dataclass, field
from typing import List, Dict, Optional

class Street:
    PREFLOP = "PREFLOP"; FLOP = "FLOP"; TURN = "TURN"; RIVER = "RIVER"

class ActionType:
    POST_ANTE="POST_ANTE"; POST_BLIND="POST_BLIND"; STRADDLE="STRADDLE"
    DEAL_HOLE="DEAL_HOLE"; CHECK="CHECK"; BET="BET"; CALL="CALL"; RAISE="RAISE"; FOLD="FOLD"
    RETURN_UNCALLED="RETURN_UNCALLED"; SHOW="SHOW"; MUCK="MUCK"

@dataclass
class PostingMeta:
    blind_type: Optional[str] = None  # "SB" | "BB" | "Dead" | "Straddle"

@dataclass
class Seat:
    seat_no: int
    player_uid: str
    display_name: str = ""
    starting_stack: int = 0
    seat_uid: Optional[str] = None
    is_button: bool = False

@dataclass
class Action:
    order: int
    street: str
    actor_uid: Optional[str]
    action: str
    amount: int = 0
    to_amount: Optional[int] = None
    all_in: bool = False
    note: Optional[str] = None
    posting_meta: Optional[PostingMeta] = None

@dataclass
class HandMetadata:
    table_id: str
    hand_id: str
    variant: str = "NLHE"
    max_players: int = 9
    small_blind: int = 50
    big_blind: int = 100
    ante: int = 0
    rake: int = 0
    currency: str = "CHIPS"
    started_at_utc: Optional[str] = None
    ended_at_utc: Optional[str] = None
    run_count: int = 1
    button_seat_no: Optional[int] = None
    hole_cards: Dict[str, List[str]] = field(default_factory=dict)

@dataclass
class StreetState:
    board: List[str] = field(default_factory=list)
    actions: List[Action] = field(default_factory=list)

@dataclass
class PotShare:
    player_uid: str
    amount: int

@dataclass
class Pot:
    amount: int
    eligible_player_uids: List[str]
    shares: List[PotShare] = field(default_factory=list)

@dataclass
class ShowdownEntry:
    player_uid: str
    hole_cards: Optional[List[str]] = None

@dataclass
class Hand:
    metadata: HandMetadata
    seats: List[Seat]
    hero_player_uid: Optional[str] = None
    streets: Dict[str, StreetState] = field(default_factory=lambda: {
        Street.PREFLOP: StreetState(), Street.FLOP: StreetState(),
        Street.TURN: StreetState(), Street.RIVER: StreetState()
    })
    pots: List[Pot] = field(default_factory=list)
    showdown: List[ShowdownEntry] = field(default_factory=list)
    final_stacks: Dict[str, int] = field(default_factory=dict)
