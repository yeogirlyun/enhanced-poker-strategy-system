from hand_model import Hand, Street

def validate_hand(hand: Hand):
    seat_uids = {s.player_uid for s in hand.seats}
    for street in [Street.PREFLOP, Street.FLOP, Street.TURN, Street.RIVER]:
        for a in hand.streets[street].actions:
            if a.actor_uid and a.actor_uid not in seat_uids:
                raise ValueError(f"Unknown actor_uid {a.actor_uid} in street {street}")
    return True
