from hand_model import Hand

class HandsReviewPanel:
    def __init__(self):
        self.hands: list[Hand] = []

    def load_hands(self, hands: list[Hand]):
        self.hands = hands

    def display_hand(self, hand: Hand):
        print(f"Hand ID: {hand.metadata.hand_id}, BTN seat: {hand.metadata.button_seat_no}")
        for seat in hand.seats:
            print(f"Seat {seat.seat_no}: {seat.display_name} ({seat.player_uid})")
