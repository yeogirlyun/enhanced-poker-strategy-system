"""
Theme Factory - Deterministic Token Generation
Builds complete theme token sets from minimal base color palettes
"""

from .theme_utils import lighten, darken, mix, alpha_over

def build_theme(base):
    """
    Build complete theme tokens from base palette
    
    Args:
        base: dict with keys:
            - felt: Primary table surface color
            - metal: Trim/accent metallic color  
            - accent: Secondary accent color
            - raise_: Danger/raise action color
            - call: Success/call action color
            - neutral: Neutral gray base
            - text: Primary text color
    
    Returns:
        Complete token dictionary for all UI elements
    """
    felt = base["felt"]
    metal = base["metal"] 
    accent = base["accent"]
    raise_c = base["raise_"]
    call_c = base["call"]
    neutral = base["neutral"]
    txt = base["text"]
    
    # Build comprehensive token set
    tokens = {
        # === SURFACES ===
        "table.felt": felt,
        "table.rail": darken(felt, 0.75),
        "table.inlay": metal,
        "table.edgeGlow": darken(felt, 0.6),
        "table.centerPattern": lighten(felt, 0.06),  # Subtle ellipse at center
        
        # === TEXT ===
        "text.primary": lighten(txt, 0.10),
        "text.secondary": lighten(txt, 0.35), 
        "text.muted": lighten(txt, 0.55),
        
        # === CARDS ===
        # Neutral ivory face, theme-tinted back
        "card.face.bg": lighten(neutral, 0.85),
        "card.face.border": darken(neutral, 0.50),
        "card.pip.red": mix(raise_c, "#FF2A2A", 0.35),
        "card.pip.black": darken(neutral, 0.85),
        
        "card.back.bg": alpha_over(accent, felt, 0.35),
        "card.back.pattern": alpha_over(metal, accent, 0.25),
        "card.back.border": metal,
        
        # === COMMUNITY BOARD ===
        "board.slotBg": alpha_over(darken(felt, 0.45), felt, 0.80),
        "board.border": alpha_over(metal, felt, 0.85),
        "board.shadow": darken(felt, 0.85),
        
        # === CHIPS ===
        # Standard casino colors with theme-tinted rims
        "chip.$1": "#2E86AB",     # Blue
        "chip.$5": "#B63D3D",     # Red
        "chip.$25": "#2AA37A",    # Green
        "chip.$100": "#3C3A3A",   # Black
        "chip.$500": "#6C4AB6",   # Purple
        "chip.$1k": "#D1B46A",    # Gold
        "chip.rim": alpha_over(metal, "#000000", 0.35),
        "chip.text": "#F8F7F4",
        
        # === POT ===
        "pot.badgeBg": alpha_over(darken(felt, 0.5), felt, 0.85),
        "pot.badgeRing": metal,
        "pot.valueText": lighten(neutral, 0.9),
        
        # === BETS & ANIMATIONS ===
        "bet.path": alpha_over(accent, "#000000", 0.50),
        "bet.glow": alpha_over(metal, "#000000", 0.35),
        
        # === PLAYER LABELS ===
        "label.active.bg": alpha_over(call_c, "#000000", 0.60),
        "label.active.fg": lighten(neutral, 0.95),
        "label.folded.bg": alpha_over(neutral, "#000000", 0.75),
        "label.folded.fg": lighten(neutral, 0.65),
        "label.winner.bg": alpha_over(metal, "#000000", 0.70),
        "label.winner.fg": "#0B0B0E",
        
        # === BUTTONS (Enhanced from existing system) ===
        "btn.primary.bg": alpha_over(accent, "#000000", 0.70),
        "btn.primary.fg": lighten(neutral, 0.95),
        "btn.primary.border": metal,
        "btn.primary.hoverBg": alpha_over(accent, "#000000", 0.55),
        "btn.primary.hoverFg": "#FFFFFF",
        "btn.primary.hoverBorder": lighten(metal, 0.20),
        "btn.primary.activeBg": alpha_over(accent, "#000000", 0.85),
        "btn.primary.activeFg": "#FFFFFF", 
        "btn.primary.activeBorder": lighten(metal, 0.35),
        
        "btn.secondary.bg": alpha_over(neutral, "#000000", 0.60),
        "btn.secondary.fg": lighten(txt, 0.20),
        "btn.secondary.border": alpha_over(metal, "#000000", 0.60),
        "btn.secondary.hoverBg": alpha_over(neutral, "#000000", 0.45),
        "btn.secondary.hoverFg": lighten(txt, 0.35),
        "btn.secondary.hoverBorder": alpha_over(metal, "#000000", 0.45),
        
        "btn.danger.bg": alpha_over(raise_c, "#000000", 0.70),
        "btn.danger.fg": lighten(neutral, 0.95),
        "btn.danger.border": lighten(raise_c, 0.20),
        "btn.danger.hoverBg": alpha_over(raise_c, "#000000", 0.55),
        "btn.danger.hoverFg": "#FFFFFF",
        "btn.danger.hoverBorder": lighten(raise_c, 0.35),
        
        # === PLAYER SEATS ===
        "seat.bg.idle": alpha_over(neutral, felt, 0.25),
        "seat.bg.active": alpha_over(call_c, felt, 0.15),
        "seat.bg.acting": alpha_over(call_c, "#000000", 0.40),
        "seat.bg.folded": alpha_over(neutral, "#000000", 0.70),
        "seat.ring": alpha_over(metal, felt, 0.60),
        "seat.highlight": lighten(felt, 0.15),
        "seat.shadow": darken(felt, 0.80),
        
        # === DEALER BUTTON ===
        "dealer.buttonBg": lighten(neutral, 0.90),
        "dealer.buttonFg": darken(neutral, 0.85),
        "dealer.buttonBorder": metal,
        
        # === ACTION COLORS ===
        "action.fold": alpha_over(neutral, "#000000", 0.60),
        "action.check": alpha_over(call_c, "#000000", 0.50),
        "action.call": call_c,
        "action.bet": alpha_over(metal, call_c, 0.70),
        "action.raise": raise_c,
        "action.allin": alpha_over(raise_c, metal, 0.60),
        
        # === ACCESSIBILITY & CHROME ===
        "a11y.focus": lighten(metal, 0.30),
        "divider": darken(felt, 0.70),
        "grid.lines": darken(felt, 0.60),
        
        # === MICRO-INTERACTIONS ===
        "glow.soft": alpha_over(metal, "#000000", 0.20),
        "glow.medium": alpha_over(metal, "#000000", 0.40),
        "glow.strong": alpha_over(metal, "#000000", 0.70),
        "pulse.slow": alpha_over(call_c, "#000000", 0.30),
        "pulse.fast": alpha_over(raise_c, "#000000", 0.50),
        
        # === TYPOGRAPHY ===
        "font.display": ("Inter", 24, "bold"),
        "font.h1": ("Inter", 20, "bold"),
        "font.h2": ("Inter", 16, "semibold"),
        "font.body": ("Inter", 14, "normal"),
        "font.small": ("Inter", 12, "normal"),
        "font.mono": ("JetBrains Mono", 12, "normal"),
    }
    
    return tokens

# Base color palettes for all 16 themes
THEME_BASES = {
    # Row 1 — Classic
    "Forest Green Professional": {
        "felt": "#1E4D2B", "metal": "#C9A86A", "accent": "#2E7D32",
        "raise_": "#B63D3D", "call": "#2AA37A", "neutral": "#9AA0A6", "text": "#EDECEC"
    },
    "Velvet Burgundy": {
        "felt": "#4A1212", "metal": "#C0A066", "accent": "#702525", 
        "raise_": "#B53A44", "call": "#2AA37A", "neutral": "#A29A90", "text": "#F2E9DF"
    },
    "Obsidian Gold": {
        "felt": "#0A0A0A", "metal": "#D4AF37", "accent": "#2C2C2C",
        "raise_": "#A41E34", "call": "#2AA37A", "neutral": "#A7A7A7", "text": "#E6E6E6"
    },
    "Imperial Jade": {
        "felt": "#0F4736", "metal": "#CFAF63", "accent": "#166A3E",
        "raise_": "#B23B43", "call": "#32B37A", "neutral": "#9CB1A8", "text": "#F9F3DD"
    },
    
    # Row 2 — Luxury Noir
    "Monet Noir": {
        "felt": "#0B1622", "metal": "#C8D5DE", "accent": "#0E7A6F",
        "raise_": "#B63D3D", "call": "#2AA37A", "neutral": "#8EA6B5", "text": "#F5F7FA"
    },
    "Caravaggio Noir": {
        "felt": "#0A0A0C", "metal": "#E1C16E", "accent": "#9E0F28",
        "raise_": "#B3122E", "call": "#2AA37A", "neutral": "#9C8F7A", "text": "#FFF7E6"
    },
    "Klimt Royale": {
        "felt": "#17130E", "metal": "#E4C97D", "accent": "#166A3E",
        "raise_": "#B23B43", "call": "#32B37A", "neutral": "#A38E6A", "text": "#FFF2D9"
    },
    "Deco Luxe": {
        "felt": "#0E0F11", "metal": "#D6C08F", "accent": "#1A3E34",
        "raise_": "#5B1922", "call": "#2AA37A", "neutral": "#9B9486", "text": "#F8F4EA"
    },
    
    # Row 3 — Nature & Light  
    "Sunset Mirage": {
        "felt": "#2B1C1A", "metal": "#E6B87A", "accent": "#C16E3A",
        "raise_": "#C85C5C", "call": "#2AA37A", "neutral": "#A68C7A", "text": "#F7E7D6"
    },
    "Oceanic Blue": {
        "felt": "#0F1620", "metal": "#B7C1C8", "accent": "#3B6E8C",
        "raise_": "#6C94D2", "call": "#57C2B6", "neutral": "#9DB3C4", "text": "#F5F7FA"
    },
    "Velour Crimson": {
        "felt": "#6E0B14", "metal": "#C18F65", "accent": "#3B0A0F",
        "raise_": "#A41E34", "call": "#2AA37A", "neutral": "#A3928A", "text": "#F5E2C8"
    },
    "Golden Dusk": {
        "felt": "#5C3A21", "metal": "#C18F65", "accent": "#A3622B",
        "raise_": "#B35A3B", "call": "#2AA37A", "neutral": "#AF9A8A", "text": "#F3E3D3"
    },
    
    # Row 4 — Modern / Bold
    "Cyber Neon": {
        "felt": "#0D0F13", "metal": "#9BE3FF", "accent": "#17C3E6",
        "raise_": "#D65DB1", "call": "#00D9A7", "neutral": "#A3A8B3", "text": "#EAF8FF"
    },
    "Stealth Graphite": {
        "felt": "#111214", "metal": "#8D8D8D", "accent": "#232629",
        "raise_": "#9E3B49", "call": "#57C2B6", "neutral": "#8E9196", "text": "#E6E7EA"
    },
    "Royal Sapphire": {
        "felt": "#0B1F36", "metal": "#C7D3E0", "accent": "#224D8F",
        "raise_": "#6C4AB6", "call": "#57C2B6", "neutral": "#9AB1CF", "text": "#F2F6FC"
    },
    "Midnight Aurora": {
        "felt": "#0E1A28", "metal": "#D0D9DF", "accent": "#1C3E4A",
        "raise_": "#6FB5E7", "call": "#7BD0BC", "neutral": "#98A8B8", "text": "#F5F7FA"
    },
}

def build_all_themes():
    """Build complete token sets for all 16 themes"""
    return {name: build_theme(base) for name, base in THEME_BASES.items()}
