# PokerPro Trainer — **UI Implementation Handbook** (v1.1)
**Date**: 2025-08-18  
**Audience**: AI coding agents & human reviewers  
**Status**: Authoritative — Do **not** deviate without updating this handbook.

> Golden rule: **UI renders state; events mutate state via PPSM; effects live at the edges.**

---

## 0) Purpose & Scope
This handbook locks down the **UI-side implementation rules** for PokerPro so contributors and AI agents **do not invent new patterns**. It covers session UIs (Practice, Hands Review, GTO), rendering rules, contracts with PPSM, theming, logging, testing, and a detailed **GameDirector** contract for sounds, animations, and autoplay.

---

## 1) Canonical Architecture (Summary)
- **Coordinator**: Single-threaded, event-driven **GameDirector** orchestrates timing (autoplay, effect gating).  
- **Store**: One source of truth per session. No duplicate state or cross-writes.  
- **Domain**: **PPSM** (PurePokerStateMachine) is deterministic and authoritative for poker rules.  
- **UI**: **Render-only**. Emits **intents** → adapter builds **domain events** → `ppsm.transition(state, event)` → Store update.  
- **Adapters**: Sounds, persistence, estimators, external APIs — side-effectful but stateless re: domain.  
- **Renderer Pipeline**: Composable canvas layers (felt → seats → community → pot → overlays).

---

### 1.1) **Poker Table — Pure Renderer & Reuse Contract**
The poker table is implemented as a **pure renderer** (`backend/ui/renderers/poker_table_renderer.py`).

Authoritative rules:
- Input: one immutable `PokerTableState` (in `backend/ui/table/state.py`).
- Output: optional renderer intents (e.g., `{type: "REQUEST_ANIMATION", payload: effect}`) — no business logic.
- No PPSM calls, no timers, no side effects; purely draws state via tableview components.
- Common across Practice, Hands Review, and GTO sessions; differences live in the **SessionManager**.

Minimal usage:
```python
renderer = PokerTableRenderer(parent, intent_handler, theme_manager)
renderer.render(PokerTableState(...))
```

Effects:
- Renderer emits intents; the shell forwards to EventBus `effect_bus:animate`.
- `EffectBus` bridges to `ChipAnimations` and coordinates gating via **GameDirector**.

Layer order (must): `felt → seats → stacks → community → bets → pot → action → status → overlay → temp_animation`.

### 1.2) **GameDirector — Role & Scope (Authoritative)**
**Goal**: Centralize time, autoplay, and effect sequencing to keep behavior **deterministic, cancellable, and single-threaded**.

**The Director does:**
- Maintain **play/pause/seek/speed** for session playback.
- Schedule **AUTO_ADVANCE** during autoplay at the configured interval.
- **Gate effects** so autoplay only advances after required animations/sounds complete.
- Emit **time events** (`TIMER_TICK`, `TIMER_EXPIRED`) when sessions use timers.
- Coordinate the **EffectBus** (sounds/animations/haptics) via completion events.

**The Director does *not* do:**
- Poker legality or domain rules (PPSM only).  
- Hold domain state (Store is the single source of truth).  
- Use threads or blocking calls (everything single-threaded and queued).

**Minimal API**
```python
class GameDirector:
    def schedule(self, delay_ms: int, event: dict) -> str: ...
    def cancel(self, token: str) -> None: ...
    def play(self) -> None: ...
    def pause(self) -> None: ...
    def step_forward(self, n: int = 1) -> None: ...
    def step_back(self, n: int = 1) -> None: ...
    def seek(self, step_index: int) -> None: ...
    def set_speed(self, multiplier: float) -> None: ...
    def set_autoplay_interval(self, ms: int) -> None: ...

    # Effect gating
    def gate_begin(self) -> None: ...
    def gate_end(self) -> None: ...  # call on ANIM_COMPLETE/SOUND_COMPLETE
```

**Event catalog it may emit**
- `AUTO_ADVANCE` (autoplay next step)
- `TIMER_TICK` / `TIMER_EXPIRED` (if timers are used)
- `ANIM_COMPLETE`, `SOUND_COMPLETE` (posted by EffectBus through Director)

**Timing policy**
- Single-threaded, pumped from UI loop (e.g., Tk `after(16, pump)`).  
- **Speed** scales scheduled delays (`delay_ms / speed`).  
- Time is **fakeable** in tests via an injected clock.

**Integration flow**
```
UI intent → Adapter builds domain event → ppsm.transition → Store.replace →
Renderer renders (pure) → EffectBus interprets effects → Director gates & schedules AUTO_ADVANCE
```

---

## 2) Feature mapping to Renderer / Director / Effects
| Feature | Trigger | Who decides | Director role | Effects / Events |
|---|---|---|---|---|
| **Player highlighting (current actor glow)** | Store state (`seats[i].acting`) | Renderer (pure) | None (render-only) | No effect; renderer reads acting seat |
| **Action sounds (BET/CALL/CHECK/FOLD, etc.)** | After `ppsm.transition` on action events | Reducer adds `SOUND` effect | Gate if sound duration blocks autoplay | `SOUND(id)` → `SOUND_COMPLETE` after duration |
| **Deal sounds (cards)** | On `DEAL_*` events | Reducer adds `SOUND('deal')` | Optional gate | `SOUND('deal')` |
| **End-of-street chips-to-pot animation** | On transition to next street | Reducer adds `ANIMATE('chips_to_pot')` (+ optional sound) | **Gate** until complete | `ANIMATE('chips_to_pot', ms=250)` → `ANIM_COMPLETE` |
| **Showdown / last-player standing** | On `SHOWDOWN` or only one active | Reducer adds `ANIMATE('pot_to_winner')` + `SOUND('chips_scoop')` + `BANNER('winner')` | **Gate** until complete | `ANIMATE('pot_to_winner', ms=500)`; `SOUND('chips_scoop')`; `BANNER('winner')` (non-gated visual) |
| **Autoplay** | User presses Play | Director | Schedules `AUTO_ADVANCE` if not gated | `AUTO_ADVANCE` at interval; delayed while gate > 0 |
| **Speed control** | User changes speed | Director | Scales scheduled delays | N/A |
| **Seek / Step** | User seeks/steps | Director + Shell | Resets playback position; cancels scheduled events | N/A |

**Gating rule**: If any effect in a step requires gating (e.g., chip/pot animation, long SFX), the reducer marks it so the EffectBus calls `director.gate_begin()` before starting and `director.gate_end()` on completion. Autoplay only advances when **gate count is 0**.

---

## 3) Contracts Between UI and PPSM
### 3.1 Inputs to PPSM
```json
{
  "type": "BET",
  "actor_uid": "Player2",
  "street": "TURN",
  "to_amount": 120,
  "note": null
}
```

- `type`: **UPPER_SNAKE_CASE** (e.g., `POST_BLIND`, `BET`, `RAISE`, `CALL`, `CHECK`, `FOLD`, `DEAL_FLOP`, `SHOWDOWN`)
- `street`: **PREFLOP/FLOP/TURN/RIVER** (uppercase)
- Fields: **snake_case**

### 3.2 Outputs the UI may read (via selectors)
- `currentStreet(state)` → `"TURN"`  
- `currentActor(state)` → `"Player1"`  
- `legalActions(state)` → `[ "FOLD", "CALL", "RAISE" ]` with ranges  
- `pot(state)` → `int`  
- `stacks(state)` → `{ uid: int }`  
- `board(state)` → `["Qh","7c","7d"]`  
- `handResult(state)` after `SHOWDOWN`

**Forbidden**: UI must **not** compute legality or mutate domain state.

---

## 4) Renderer Pipeline & Components
**Layer order**: `felt → seats → stacks → community → bets → pot → action → status → overlay → temp_animation`

**Boundaries**
- **SeatPod**: avatar, name, stack, halo, badges (subscribe to seat selectors).
- **CommunityBoard**: board cards and visual-only burns.
- **PotDisplay**: pot totals/side pots/badges.
- **ActionBar**: hero legal actions (from selectors only).
- **HUD/Overlays**: actor glow, toasts, timers; no domain writes.

---

## 5) Sessions (Practice / Hands Review / GTO)
### Session Managers (Reusable Pattern)
Implement managers that own PPSM calls, state shaping, and effects. Examples:
- `PracticeSessionManager`: executes hero/bot actions, builds `PokerTableState`, adds CHIP_TO_POT effects, dispatches to Store
- `GTOSessionManager`: wraps GTO engine, provides advice, same render/effects path
- Planned `HandsReviewSessionManager`: drives trace steps, produces `PokerTableState` and effects

Renderer is shared across all sessions; managers isolate differences.

### 5.2 Hands Review
- Step / Play / Pause / Seek / Speed.  
- Each trace step → domain event; reducer computes effects.  
- Director gates effects so autoplay advances only after completions.

### 5.3 GTO Session
- All non-hero decisions via DecisionEngine; deterministic for seed/state.  
- Explanations come from engine outputs (UI never invents analysis).  
- Effects like Practice; Director coordinates autoplay and gating.

---

## 6) Theme & Design System (Tokens are mandatory)
Use **ThemeManager** tokens; **no literal colors** in components.

Tokens (subset):  
```
a11y.focus, board.border, board.cardBack, board.cardFaceFg, board.slotBg, btn.active.bg, btn.default.bg, btn.hover.bg, burgundy.base, burgundy.bright, burgundy.deep, chip_gold, dealer.buttonBg, dealer.buttonBorder, dealer.buttonFg, emerald.base, emerald.bright, gold.base, gold.bright, gold.dim, panel.bg, panel.border, panel.fg, player.name, player.stack, pot.badgeBg, pot.badgeRing, pot.valueText, primary_bg, seat.bg.acting, seat.bg.active, seat.bg.idle, secondary_bg, table.center, table.edgeGlow, table.felt, table.inlay, table.rail, table.railHighlight, text.muted, text.primary, text.secondary, text_gold, theme_config.json
```

- Accessibility: WCAG ≥ 4.5:1; focus via `a11y.focus`.  
- Targets ≥ 44×44; fonts/cards scale per responsive rules.  
- Live theme switching: components re-render on token change.

---

## 7) EffectBus & Sound Catalog (standardize IDs)
**Effect types**: `SOUND`, `ANIMATE`, `BANNER`, `VIBRATE`, `TOAST`

**Sound IDs (examples; keep stable for mapping):**
- `fx.deal`, `fx.bet_single`, `fx.bet_multi`, `fx.call`, `fx.check`, `fx.fold`, `fx.raise`, `fx.chips_scoop`, `fx.win_fanfare`

**Animation names (examples):**
- `chips_to_pot`, `pot_to_winner`, `actor_glow_pulse`

**Durations**: Use **config** to define canonical durations (ms) for gating; do not measure audio runtime at render time.

---

## 8) Error Handling, Logging, and Telemetry
- Log with ISO timestamps and `module:file:line`; no PII.  
- On invalid event: log step index & `hand_id`, disable controls until Reset/Skip.  
- Director logs: `scheduled`, `executed`, `canceled`, `gated_begin/end` (for CI debugging).

---

## 9) File/Folder Structure (UI)
```
ui/
  store/                 # session store + reducers
    index.py
    selectors.py
  components/
    seat_pod.py
    community_board.py
    pot_display.py
    action_bar.py
    overlays/
  renderer/
    canvas_manager.py
    layer_manager.py
    renderer_pipeline.py
  adapters/
    ppsm_adapter.py
    decision_engine.py
    sound_bus.py
    effect_bus.py
  sessions/
    practice_shell.py
    review_shell.py
    gto_shell.py
  director/
    director.py          # GameDirector + NoopDirector + injected clock
```

---

## 10) Testing Requirements (must pass for PR merge)
- **Unit**: reducers, selectors, adapters, director (scheduling, gating).  
- **Snapshot**: major components across key states.  
- **Replay**: hand traces replay with no divergence; mismatches reported.  
- **Headless**: fake clock; autoplay produces stable PPSM state hashes.

---

## 11) AI Agent Guardrails (read carefully)
1. **Do not add new events or fields.** If missing, leave TODO and stop.  
2. **Never compute poker legality in UI.** Call selectors or PPSM.  
3. **Use theme tokens only.** No literal colors, shadows, fonts.  
4. **No timers/threads in components.** Use **GameDirector** for all timing and autoplay.  
5. **No cross-component writes.** Only Store and events.  
6. **Respect casing rules** (events UPPER_SNAKE_CASE; domain snake_case; streets uppercase).  
7. **Keep functions small and pure**; side effects only in adapters/EffectBus.  
8. **If uncertain**, generate interface stubs, not ad‑hoc logic.

---

### Appendix A — Example Reducer Effects
```python
def reducer_transition(state, evt):
    new_state = ppsm.transition(state, evt)
    effects = []

    if evt["type"] in ('BET', 'RAISE'):
        effects.append({"type": "SOUND", "id": "fx.bet_single", "ms": 220})
    elif evt["type"] == "CALL":
        effects.append({"type": "SOUND", "id": "fx.call", "ms": 180})
    elif evt["type"] == "CHECK":
        effects.append({"type": "SOUND", "id": "fx.check", "ms": 140})
    elif evt["type"] == "FOLD":
        effects.append({"type": "SOUND", "id": "fx.fold", "ms": 160})

    if street_ended(state, new_state):
        effects.append({"type": "ANIMATE", "name": "chips_to_pot", "ms": 260})

    if showdown_or_last_player(new_state):
        effects += [
            {"type": "ANIMATE", "name": "pot_to_winner", "ms": 520},
            {"type": "SOUND", "id": "fx.chips_scoop", "ms": 420},
            {"type": "BANNER", "name": "winner", "ms": 800},
        ]

    return new_state, effects
```

### Appendix B — EffectBus Skeleton
```python
def run_effects(effects: list[dict], director: GameDirector, sound_bus, renderer):
    gated = any(e["type"] in {"ANIMATE", "SOUND"} for e in effects)
    if gated: director.gate_begin()

    for e in effects:
        if e["type"] == "SOUND":
            sound_bus.play(e["id"])
            director.schedule(e.get("ms", 200), {"type": "SOUND_COMPLETE", "id": e["id"]})
        elif e["type"] == "ANIMATE":
            renderer.animate(e["name"], e.get("args", {}))
            director.schedule(e.get("ms", 250), {"type": "ANIM_COMPLETE", "name": e["name"]})
        elif e["type"] == "BANNER":
            renderer.banner(e["name"], e.get("ms", 800))

    if gated:
        # In your event handler for *_COMPLETE, call director.gate_end()
        pass
```

